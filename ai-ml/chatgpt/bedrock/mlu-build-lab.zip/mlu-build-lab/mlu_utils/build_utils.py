def tree_of_thoughts(campaign, invoke_fn, render_fn=None, depth=2, branching_factor=3, beam_width=2, verbose=False):
    """Run Tree-of-Thoughts with LLM-driven beam search.

    Multi-level: at each depth level, branches are proposed, scored, and pruned.
    Only the top `beam_width` paths survive to the next level. The final level
    expands the winner into subthemes.

    Args:
        campaign: Campaign name/description string.
        invoke_fn: Function to call the LLM (signature: invoke(prompt, **kwargs) -> str).
        render_fn: Optional function to visualize the tree (render_tot_tree).
        depth: Number of reasoning levels (1 = original simple version).
        branching_factor: Number of candidate themes proposed per level.
        beam_width: Number of best paths to keep at each level.
        verbose: If True, print progress at each level.

    Returns:
        Dict with best_theme, score, all_branches, all_scores, and subthemes.
    """
    from mlu_utils.display import display_markdown

    def to_int(s):
        digits = "".join(ch for ch in str(s) if ch.isdigit())
        return int(digits) if digits else 0

    def clean_lines(text):
        if not text:
            return []
        return [b.strip(" -*0123456789.") for b in str(text).splitlines() if b.strip()]

    # Each "path" is a list of refinement steps leading to a theme
    # Start with empty paths
    frontier = [("", 0)]  # (theme_so_far, score)

    # Track all branches and scores for visualization (first level)
    first_branches = []
    first_scores = []
    all_levels = []  # For multi-level visualization

    for level in range(depth):
        candidates = []

        for path_theme, _ in frontier:
            # Generate candidate themes/refinements
            if level == 0:
                prompt = (
                    f"Propose {branching_factor} distinct gift-theme directions for a "
                    f"'{campaign}' landing page. "
                    "Reply with one short theme name per line, nothing else."
                )
            else:
                prompt = (
                    f"The theme '{path_theme}' was selected for a '{campaign}' landing page. "
                    f"Propose {branching_factor} more specific variations or refinements of this theme. "
                    "Reply with one short theme name per line, nothing else."
                )

            branches_raw = invoke_fn(prompt, temperature=0.8, max_tokens=150)
            branches = clean_lines(branches_raw)[:branching_factor]
            if not branches:
                continue

            # Score each branch
            for b in branches:
                rating = invoke_fn(
                    f"Theme '{b}' for {campaign}. Rate 1-10 for breadth of gift coverage "
                    "and shopper appeal. Reply with ONLY the number.",
                    max_tokens=10,
                )
                score = to_int(rating)
                candidates.append((b, score))

        if not candidates:
            display_markdown(
                f"**Level {level + 1}:** no candidates parsed from LLM response — retry or lower temperature"
            )
            return {
                "best_theme": None,
                "score": 0,
                "subthemes": [],
                "all_branches": [],
                "all_scores": [],
            }

        # Sort by score descending
        candidates.sort(key=lambda x: x[1], reverse=True)

        # Save first level for visualization
        if level == 0:
            first_branches = [c[0] for c in candidates]
            first_scores = [c[1] for c in candidates]

        # Track this level for multi-level visualization
        selected_indices = list(range(min(beam_width, len(candidates))))
        all_levels.append({
            "branches": [c[0] for c in candidates],
            "scores": [c[1] for c in candidates],
            "selected": selected_indices,
        })

        if verbose:
            display_markdown(f"**Level {level + 1}:** {len(candidates)} candidates, "
                           f"best = `{candidates[0][0]}` (score {candidates[0][1]})")

        # Prune: keep only top beam_width
        frontier = candidates[:beam_width]

    # Winner
    best, best_score = frontier[0]

    # Expand winner into subthemes
    expansion = invoke_fn(
        f"Expand the theme '{best}' into exactly 3 subthemes for a '{campaign}' campaign. "
        "Reply with one short subtheme per line, nothing else.",
    )
    subthemes = clean_lines(expansion)[:3]

    display_markdown(f"**Best theme:** `{best}`  (score {best_score})")

    # Visualize using the caller-supplied renderer. Lab 3 passes the
    # single-level render_tot_tree, while render_tot_tree_multi accepts levels.
    if render_fn:
        import inspect

        try:
            renderer_params = inspect.signature(render_fn).parameters
        except (TypeError, ValueError):
            renderer_params = {}

        if "levels" in renderer_params and "branches" not in renderer_params:
            render_fn(
                root=campaign,
                levels=all_levels,
                leaves=subthemes,
            )
        else:
            render_fn(
                root=campaign,
                branches=first_branches,
                scores=first_scores,
                best_index=0,
                leaves=subthemes,
            )

    return {
        "best_theme": best,
        "score": best_score,
        "subthemes": subthemes,
        "all_branches": first_branches,
        "all_scores": first_scores,
    }
