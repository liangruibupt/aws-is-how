from typing import Union

from IPython.display import HTML, Markdown, display

from .utils import format_content, load_text_file


def display_markdown(text: Union[str, list]):
    """Uses IPython to display markdown output.  `text` can be a string or list"""
    if type(text) is str:
        display(Markdown(text))
    else:
        for t in text:
            display(Markdown(t))


def display_solution(file_name: str, **kwargs):
    """Uses IPython to display markdown content with formatting transformation."""
    content = load_text_file(file_name)

    if file_name.endswith(".py"):
        content = f"```python\n{content}\n```"
    if file_name.endswith(".diff"):
        content = f"```diff\n{content}\n```"

    display(Markdown(format_content(content, kwargs)))


def display_agent_response(response, title="Agent Response", show_metrics=False):
    """
    Display an agent's response in a visually appealing format.

    Args:
        response: The AgentResult object containing the message and metrics
        title: Optional title for the response box (default: "Agent Response")
        show_metrics: Whether to display execution metrics and tool logs (default: False)

    Returns:
        None (displays the formatted response)
    """
    # Extract the text content from the response
    try:
        if hasattr(response, "message"):
            text_content = response.message["content"][0]["text"]
        elif isinstance(response, dict):
            text_content = response["content"][0]["text"]
        elif isinstance(response, str):
            text_content = response
        else:
            text_content = str(response)
    except (KeyError, IndexError, TypeError):
        text_content = str(response)

    # Formatting '$' correctly
    text_content = text_content.replace("$", r"$\$$")

    # Display header only
    header_html = """
    <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 12px 20px;
        border-radius: 12px;
        margin: 20px 0 10px 0;
        display: flex;
        align-items: center;
        gap: 10px;
        box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);">
        <span style="font-size: 24px;">🤖</span>
        <span style="color: white;
            font-size: 16px;
            font-weight: 600;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">{title}</span>
    </div>
    """.format(
        title=title
    )

    display(HTML(header_html))

    # Display markdown content directly
    display(Markdown(text_content))

    # Display metrics if requested
    if show_metrics and hasattr(response, "metrics"):
        metrics = response.metrics

        # Build metrics HTML
        metrics_html = """
        <div style="background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 16px 20px;
            margin: 15px 0 20px 0;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
            <div style="display: flex;
                align-items: center;
                gap: 8px;
                margin-bottom: 12px;
                padding-bottom: 10px;
                border-bottom: 1px solid #e2e8f0;">
                <span style="font-size: 16px;">📊</span>
                <span style="font-size: 14px;
                    font-weight: 600;
                    color: #475569;">Execution Metrics</span>
            </div>
        """

        # Token usage section
        if hasattr(metrics, "accumulated_usage") and metrics.accumulated_usage:
            usage = metrics.accumulated_usage
            input_tokens = usage.get("inputTokens", 0)
            output_tokens = usage.get("outputTokens", 0)

            metrics_html += """
            <div style="margin-bottom: 12px;">
                <div style="font-size: 12px; color: #64748b; margin-bottom: 6px; text-transform: uppercase; letter-spacing: 0.5px;">
                    Token Usage
                </div>
                <div style="display: flex; gap: 16px; flex-wrap: wrap;">
                    <div style="background: #e0f2fe;
                        padding: 8px 12px;
                        border-radius: 6px;
                        font-size: 13px;">
                        <span style="color: #0369a1;">Input:</span>
                        <span style="font-weight: 600; color: #0c4a6e;">{input_tokens:,}</span>
                    </div>
                    <div style="background: #dcfce7;
                        padding: 8px 12px;
                        border-radius: 6px;
                        font-size: 13px;">
                        <span style="color: #15803d;">Output:</span>
                        <span style="font-weight: 600; color: #14532d;">{output_tokens:,}</span>
                    </div>
                </div>
            </div>
            """.format(
                input_tokens=input_tokens,
                output_tokens=output_tokens,
            )

        # Latency and cycles
        latency_ms = 0
        if hasattr(metrics, "accumulated_metrics") and metrics.accumulated_metrics:
            latency_ms = metrics.accumulated_metrics.get("latencyMs", 0)

        cycle_count = getattr(metrics, "cycle_count", 0)

        metrics_html += """
        <div style="margin-bottom: 12px;">
            <div style="font-size: 12px; color: #64748b; margin-bottom: 6px; text-transform: uppercase; letter-spacing: 0.5px;">
                Performance
            </div>
            <div style="display: flex; gap: 16px; flex-wrap: wrap;">
                <div style="background: #fef3c7;
                    padding: 8px 12px;
                    border-radius: 6px;
                    font-size: 13px;">
                    <span style="color: #b45309;">⏱️ Latency:</span>
                    <span style="font-weight: 600; color: #78350f;">{latency_sec:.2f}s</span>
                </div>
                <div style="background: #fee2e2;
                    padding: 8px 12px;
                    border-radius: 6px;
                    font-size: 13px;">
                    <span style="color: #dc2626;">🔄 Cycles:</span>
                    <span style="font-weight: 600; color: #991b1b;">{cycle_count}</span>
                </div>
            </div>
        </div>
        """.format(
            latency_sec=latency_ms / 1000, cycle_count=cycle_count
        )

        # Tool usage section
        if hasattr(metrics, "tool_metrics") and metrics.tool_metrics:
            metrics_html += """
            <div>
                <div style="font-size: 12px; color: #64748b; margin-bottom: 6px; text-transform: uppercase; letter-spacing: 0.5px;">
                    Tool Usage
                </div>
                <div style="background: white;
                    border: 1px solid #e2e8f0;
                    border-radius: 6px;
                    overflow: hidden;">
            """

            tool_list = list(metrics.tool_metrics.items())
            for idx, (tool_name, tool_metric) in enumerate(tool_list):
                call_count = getattr(tool_metric, "call_count", 0)
                success_count = getattr(tool_metric, "success_count", 0)
                error_count = getattr(tool_metric, "error_count", 0)
                total_time = getattr(tool_metric, "total_time", 0)

                # Determine status color
                if error_count > 0:
                    status_color = "#ef4444"
                    status_bg = "#fee2e2"
                else:
                    status_color = "#10b981"
                    status_bg = "#d1fae5"

                # No border on last item
                border_style = (
                    "border-bottom: 1px solid #e2e8f0;" if idx < len(tool_list) - 1 else ""
                )

                metrics_html += """
                <div style="padding: 10px 12px;
                    {border_style}
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    flex-wrap: wrap;
                    gap: 8px;">
                    <div style="display: flex; align-items: center; gap: 8px;">
                        <span style="font-size: 14px;">🔧</span>
                        <span style="font-size: 13px;
                            font-weight: 500;
                            color: #334155;">{tool_name}</span>
                    </div>
                    <div style="display: flex; gap: 8px; flex-wrap: wrap;">
                        <span style="background: {status_bg};
                            color: {status_color};
                            padding: 2px 8px;
                            border-radius: 4px;
                            font-size: 11px;
                            font-weight: 500;">{success_count}/{call_count} calls</span>
                        <span style="background: #f1f5f9;
                            color: #475569;
                            padding: 2px 8px;
                            border-radius: 4px;
                            font-size: 11px;">{total_time:.3f}s</span>
                    </div>
                </div>
                """.format(
                    tool_name=tool_name,
                    call_count=call_count,
                    success_count=success_count,
                    total_time=total_time,
                    status_bg=status_bg,
                    status_color=status_color,
                    border_style=border_style,
                )

            metrics_html += """
                </div>
            </div>
            """

        metrics_html += "</div>"

        display(HTML(metrics_html))
