"""Temperature Explorer widget for Lab 2 (Inference Parameters).

Uses ipywidgets so the Generate button output renders *inside* the widget,
not in a separate cell output. The learner types a prompt, picks one or more
sampling temperatures, and sees the model's output for each temperature
side by side.

Also exposes ``compare_temperatures()`` as a standalone function for
direct use in code cells.
"""

import html as _html

import boto3
import ipywidgets as widgets
from IPython.display import HTML, display

MODEL_ID = "amazon.nova-lite-v1:0"

_bedrock = boto3.client("bedrock-runtime")


def _generate(prompt: str, temperature: float, max_tokens: int = 300) -> str:
    """Single Bedrock Converse call at a given temperature."""
    response = _bedrock.converse(
        modelId=MODEL_ID,
        messages=[{"role": "user", "content": [{"text": prompt}]}],
        inferenceConfig={"maxTokens": max_tokens, "temperature": float(temperature)},
    )
    text = response["output"]["message"]["content"][0]["text"]
    return text[:200] + "..." if len(text) > 200 else text


def compare_temperatures(prompt, temps=(0.0, 0.5, 1.0), max_tokens=300):
    """Generate ``prompt`` at each temperature in ``temps`` and show the outputs
    side by side in styled cards.

    Callable directly from any code cell::

        compare_temperatures("Suggest a holiday gift theme", [0.0, 0.5, 1.0])
    """
    from IPython.display import Markdown
    import ipywidgets as _widgets

    temps = list(temps)
    cards = []
    for t in temps:
        try:
            body = _generate(prompt, t, max_tokens)
            head_bg = "#43004d"
            label = f"temperature = {t}"
        except Exception as exc:
            body = f"**Error:** {exc}"
            head_bg = "#d84a4a"
            label = f"temperature = {t} (error)"

        header_html = _widgets.HTML(
            f'<div style="background:{head_bg};color:white;padding:8px 12px;'
            f'font-weight:bold;font-size:14px;border-radius:6px 6px 0 0;">{label}</div>'
        )
        body_output = _widgets.Output()
        with body_output:
            display(Markdown(body))

        card = _widgets.VBox(
            [header_html, body_output],
            layout=_widgets.Layout(
                flex="1",
                min_width="240px",
                border="2px solid #e3d8e5",
                border_radius="8px",
                overflow="hidden",
            ),
        )
        cards.append(card)

    prompt_html = _widgets.HTML(
        f'<div style="background:#f0ebf1;border-left:4px solid #43004d;'
        f'border-radius:6px;padding:10px 14px;margin-bottom:12px;'
        f'font-family:\'Amazon Ember Display\',sans-serif;">'
        f'<span style="font-size:14px;color:#574c59;font-weight:bold;">PROMPT:</span> '
        f'<span style="font-size:14px;color:#1f0024;">{_html.escape(str(prompt))}</span></div>'
    )

    cards_box = _widgets.HBox(
        cards,
        layout=_widgets.Layout(gap="12px", flex_flow="row wrap"),
    )

    display(_widgets.VBox([prompt_html, cards_box]))


def temperature_explorer(
    default_prompt="Suggest one creative gift theme for a 'Last Minute Holiday Gifting' landing page.",
):
    """Render the interactive Temperature Explorer widget using ipywidgets.

    Results render inside the widget output area (same cell).
    """
    # --- Prompt input ---
    prompt_input = widgets.Textarea(
        value=default_prompt,
        placeholder="Enter your prompt here...",
        layout=widgets.Layout(width="100%", height="80px"),
    )
    prompt_input.style.description_width = "0px"

    # --- Temperature checkboxes ---
    temp_0 = widgets.Checkbox(value=True, description="❄️ 0.0 (Focused)", indent=False)
    temp_05 = widgets.Checkbox(value=True, description="⚖️ 0.5 (Balanced)", indent=False)
    temp_1 = widgets.Checkbox(value=True, description="🔥 1.0 (Creative)", indent=False)

    temp_box = widgets.HBox(
        [temp_0, temp_05, temp_1],
        layout=widgets.Layout(gap="20px"),
    )

    # --- Generate button ---
    generate_btn = widgets.Button(
        description="⚡ Generate",
        button_style="",
        layout=widgets.Layout(width="140px", height="36px", border_radius="20px"),
    )
    generate_btn.style.button_color = "#43004d"
    generate_btn.style.text_color = "white"

    # --- Output area (results render here, inside the widget) ---
    output_area = widgets.Output()

    # --- Button click handler ---
    def on_generate(btn):
        temps = []
        if temp_0.value:
            temps.append(0.0)
        if temp_05.value:
            temps.append(0.5)
        if temp_1.value:
            temps.append(1.0)

        output_area.clear_output(wait=True)
        with output_area:
            if not temps:
                display(HTML(
                    '<span style="color:#d84a4a;font-size:14px;">'
                    "Please select at least one temperature.</span>"
                ))
                return
            if not prompt_input.value.strip():
                display(HTML(
                    '<span style="color:#d84a4a;font-size:14px;">'
                    "Please enter a prompt.</span>"
                ))
                return
            display(HTML(
                '<span style="font-size:14px;color:#574c59;">'
                "⏳ Generating...</span>"
            ))

        # Run generation and display results
        output_area.clear_output(wait=True)
        with output_area:
            compare_temperatures(prompt_input.value.strip(), temps)

    generate_btn.on_click(on_generate)

    # --- Header ---
    header = widgets.HTML(
        '<div style="font-family:\'Amazon Ember Display\',sans-serif;">'
        '<h3 style="color:#43004d;margin:0 0 4px 0;">🌡️ Temperature Explorer</h3>'
        '<p style="font-size:14px;color:#574c59;margin:0 0 12px 0;">'
        "Enter a prompt, pick one or more temperatures, and click Generate to "
        "compare the model's output side by side.</p></div>"
    )

    # --- Assemble widget ---
    prompt_label = widgets.HTML(
        '<span style="font-size:13px;font-weight:bold;color:#43004d;'
        'text-transform:uppercase;letter-spacing:0.5px;">📝 Prompt</span>'
    )
    temp_label = widgets.HTML(
        '<span style="font-size:13px;font-weight:bold;color:#43004d;'
        'text-transform:uppercase;letter-spacing:0.5px;">🌡️ Temperatures</span>'
    )

    widget = widgets.VBox(
        [
            header,
            prompt_label,
            prompt_input,
            temp_label,
            temp_box,
            widgets.HBox([generate_btn], layout=widgets.Layout(justify_content="center", margin="12px 0 16px 0")),
            output_area,
        ],
        layout=widgets.Layout(
            border="2px solid #e3d8e5",
            border_radius="16px",
            padding="16px",
            width="100%",
        ),
    )

    display(widget)
