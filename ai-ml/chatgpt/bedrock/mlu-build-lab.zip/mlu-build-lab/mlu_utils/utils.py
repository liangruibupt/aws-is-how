import os
import re
import zipfile


def get_environment_var(var_name: str, default_value: str = None) -> str:
    """Get the value of an environment variable."""
    var_value = os.environ.get(var_name, default_value)
    if not var_value:
        raise ValueError(f"Environment configuration incorrect: required '{var_name}' missing")
    return var_value


def format_content(doc: str, data: dict):
    """Replaces special format variables in the string.  Transforms `[VAR]` to the content stored in VAR."""
    for key, val in data.items():
        doc = doc.replace(f"[{key}]", val)
    return doc


def to_snake_case(string: str) -> str:
    """Convert a CamelCase string to camel_case."""
    return re.sub("(?!^)([A-Z]+)", r"_\1", string).lower()


def load_text_file(file_name: str) -> str:
    """Load a text file into an array of lines of text."""
    with open(file_name, "r") as file:
        return file.read()


def unzip_file(zip_filename, extract_dir=None):
    """
    Extracts all contents from a ZIP file to a specified directory.
    Only extracts if the contents do not already exist.
    """
    # Create the target directory if it does not exist
    if not extract_dir:
        extract_dir = "./"

    if not os.path.exists(extract_dir):
        os.makedirs(extract_dir)

    # Check if the contents of the zip file already exist in the target directory
    try:
        with zipfile.ZipFile(zip_filename, "r") as zip_ref:
            # Get the list of files in the zip
            zip_contents = zip_ref.namelist()

            # Check if all files already exist in the target directory
            all_exist = all(
                os.path.exists(os.path.join(extract_dir, name))
                for name in zip_contents
                if not name.endswith("/")  # skip directories
            )

            if all_exist and zip_contents:
                print("Files already extracted. Skipping extraction.")
                return

            # Extract all files to the specified directory
            zip_ref.extractall(extract_dir)
        print("Files extracted!")
    except zipfile.BadZipFile as e:
        print(f"Error opening zip file: {e}")
    except Exception as e:
        print(f"An error occurred: {e}")
