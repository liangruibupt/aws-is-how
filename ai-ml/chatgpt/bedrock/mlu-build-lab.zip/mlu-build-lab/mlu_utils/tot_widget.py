"""Tree-of-Thoughts visualization widget (multi-level).

Renders an inline SVG diagram showing the ToT search tree.
Supports arbitrary depth levels — each level shows candidates with scores,
the winners highlighted, and connections to the next level.

Usage (simple — single level + expansion):

    render_tot_tree(
        root="Last Minute Holiday Gifting",
        branches=["Cozy Family Game Night", "Gifts for the Home Chef", "Beauty Gifts"],
        scores=[2, 7, 1],
        best_index=1,
        leaves=["Holiday Kitchen Upgrades", "Festive Baking Kits", "Host & Entertain"],
    )

Usage (multi-level):

    render_tot_tree_multi(
        root="Last Minute Holiday Gifting",
        levels=[
            {"branches": ["Theme A", "Theme B", "Theme C"], "scores": [6, 8, 5], "selected": [0, 1]},
            {"branches": ["A refined", "B refined", "B variant"], "scores": [7, 9, 6], "selected": [1]},
        ],
        leaves=["Subtheme 1", "Subtheme 2", "Subtheme 3"],
    )
"""

import html as _html
import uuid

from IPython.display import HTML, display

_ROYAL = "#43004d"
_ROYAL_80 = "#693371"
_CREAM = "#f0ebf1"
_BORDER = "#e3d8e5"
_TEXT = "#1f0024"
_MEDIUM = "#574c59"
_LEMON = "#ffbb45"
_LEMON_DK = "#d68100"
_GRAY = "#9f9ba0"
_GREEN = "#4aac76"


def _box(x, y, w, h, title, body, *, highlight=False, pruned=False, leaf=False):
    """One node rendered as an SVG foreignObject."""
    if pruned:
        border = _GRAY
        bw = 1
        head_bg = _GRAY
        opacity = "opacity:0.5;"
    elif highlight:
        border = _LEMON
        bw = 3
        head_bg = _LEMON
        opacity = ""
    else:
        border = _BORDER
        bw = 1.5
        head_bg = _ROYAL_80 if leaf else _ROYAL
        opacity = ""

    head_fg = _TEXT if highlight else "white"
    title_html = (
        f'<div style="background:{head_bg};color:{head_fg};padding:4px 8px;'
        f'font-weight:bold;font-size:11px;border-radius:6px 6px 0 0;white-space:nowrap;'
        f'overflow:hidden;text-overflow:ellipsis;">{_html.escape(title)}</div>'
        if title else ""
    )
    return (
        f'<foreignObject x="{x}" y="{y}" width="{w}" height="{h}">'
        f'<div xmlns="http://www.w3.org/1999/xhtml" style="box-sizing:border-box;height:100%;'
        f'border:{bw}px solid {border};border-radius:8px;background:white;overflow:hidden;{opacity}'
        f"font-family:'Amazon Ember Display','Noto Sans Display','Helvetica Neue',Arial,sans-serif;\">"
        f'{title_html}'
        f'<div style="padding:4px 8px;font-size:11px;color:{_TEXT};line-height:1.3;'
        f'overflow:hidden;text-overflow:ellipsis;">{_html.escape(body)}</div>'
        f'</div></foreignObject>'
    )


def _curve(x1, y1, x2, y2, color, marker_id):
    """Curved connector between levels."""
    return (f'<path d="M{x1},{y1} C{x1},{(y1 + y2) / 2:.0f} {x2},{(y1 + y2) / 2:.0f} {x2},{y2}" '
            f'fill="none" stroke="{color}" stroke-width="2" marker-end="url(#{marker_id})"/>')


def render_tot_tree(root, branches, scores=None, best_index=0, leaves=None,
                    title="Tree of Thoughts"):
    """Render a single-level ToT tree (backward compatible)."""
    levels = [{
        "branches": branches,
        "scores": scores or [None] * len(branches),
        "selected": [best_index],
    }]
    render_tot_tree_multi(root=root, levels=levels, leaves=leaves, title=title)


def render_tot_tree_multi(root, levels, leaves=None, title="Tree of Thoughts"):
    """Render a multi-level ToT tree as an inline SVG.

    Args:
        root: Root node label (e.g., campaign name).
        levels: List of dicts, each with:
            - branches: list of str (candidate thoughts)
            - scores: list of numbers (scores for each)
            - selected: list of int (indices that survived pruning)
        leaves: Optional final expansion leaves from the winner.
        title: Display title.
    """
    uid = uuid.uuid4().hex[:6]
    W = 960
    gap = 14
    node_h = 68
    leaf_h = 60
    row_spacing = 110
    root_w, root_h = 280, 44

    # Calculate layout
    num_levels = len(levels)
    has_leaves = leaves is not None and len(leaves) > 0

    root_y = 10
    root_x = (W - root_w) / 2

    # Position each level row
    level_rows = []
    for lvl_idx, lvl in enumerate(levels):
        n = len(lvl["branches"])
        node_w = min(220, (W - 40 - (n - 1) * gap) / max(n, 1))
        total_w = n * node_w + (n - 1) * gap
        start_x = (W - total_w) / 2
        y = root_y + root_h + 50 + lvl_idx * row_spacing
        positions = [(start_x + i * (node_w + gap), y) for i in range(n)]
        level_rows.append({
            "positions": positions,
            "node_w": node_w,
            "y": y,
        })

    # Leaf row
    if has_leaves:
        m = len(leaves)
        lw = min(200, (W - 40 - (m - 1) * gap) / max(m, 1))
        l_total = m * lw + (m - 1) * gap
        l_start = (W - l_total) / 2
        leaf_y_pos = level_rows[-1]["y"] + node_h + 50
        leaf_positions = [(l_start + i * (lw + gap), leaf_y_pos) for i in range(m)]
    else:
        leaf_y_pos = level_rows[-1]["y"] + node_h + 10

    H = (leaf_y_pos + leaf_h + 14) if has_leaves else (level_rows[-1]["y"] + node_h + 20)

    # Build SVG parts
    parts = []

    # Markers
    markers = (
        f'<marker id="{uid}_gray" markerWidth="8" markerHeight="8" refX="5" refY="3" orient="auto">'
        f'<path d="M0,0 L5,3 L0,6 Z" fill="{_GRAY}"/></marker>'
        f'<marker id="{uid}_lemon" markerWidth="8" markerHeight="8" refX="5" refY="3" orient="auto">'
        f'<path d="M0,0 L5,3 L0,6 Z" fill="{_LEMON_DK}"/></marker>'
        f'<marker id="{uid}_green" markerWidth="8" markerHeight="8" refX="5" refY="3" orient="auto">'
        f'<path d="M0,0 L5,3 L0,6 Z" fill="{_GREEN}"/></marker>'
    )

    # Connections: root → level 0
    lvl0 = level_rows[0]
    selected_0 = set(levels[0].get("selected", []))
    for i in range(len(levels[0]["branches"])):
        cx = lvl0["positions"][i][0] + lvl0["node_w"] / 2
        is_sel = i in selected_0
        parts.append(_curve(
            root_x + root_w / 2, root_y + root_h,
            cx, lvl0["y"],
            _LEMON_DK if is_sel else _GRAY,
            f"{uid}_lemon" if is_sel else f"{uid}_gray",
        ))

    # Connections: level N → level N+1
    for lvl_idx in range(num_levels - 1):
        selected = set(levels[lvl_idx].get("selected", []))
        curr_row = level_rows[lvl_idx]
        next_row = level_rows[lvl_idx + 1]

        # Connect selected nodes from current level to all nodes in next level
        for sel_i in selected:
            src_cx = curr_row["positions"][sel_i][0] + curr_row["node_w"] / 2
            src_y = curr_row["y"] + node_h

            next_selected = set(levels[lvl_idx + 1].get("selected", []))
            for j in range(len(levels[lvl_idx + 1]["branches"])):
                dst_cx = next_row["positions"][j][0] + next_row["node_w"] / 2
                is_sel = j in next_selected
                parts.append(_curve(
                    src_cx, src_y,
                    dst_cx, next_row["y"],
                    _LEMON_DK if is_sel else _GRAY,
                    f"{uid}_lemon" if is_sel else f"{uid}_gray",
                ))

    # Connections: last level winner → leaves
    if has_leaves:
        last_lvl = levels[-1]
        last_row = level_rows[-1]
        last_selected = last_lvl.get("selected", [0])
        winner_idx = last_selected[0] if last_selected else 0
        src_cx = last_row["positions"][winner_idx][0] + last_row["node_w"] / 2
        src_y = last_row["y"] + node_h

        for j in range(len(leaves)):
            dst_cx = leaf_positions[j][0] + lw / 2
            parts.append(_curve(src_cx, src_y, dst_cx, leaf_y_pos, _GREEN, f"{uid}_green"))

    # Root node
    parts.append(_box(root_x, root_y, root_w, root_h, "", f"🌳 {root}"))

    # Level nodes
    for lvl_idx, lvl in enumerate(levels):
        row = level_rows[lvl_idx]
        selected = set(lvl.get("selected", []))
        for i, branch in enumerate(lvl["branches"]):
            x, y = row["positions"][i]
            score = lvl["scores"][i] if lvl.get("scores") else None
            is_sel = i in selected

            label = f"L{lvl_idx+1} #{i+1}"
            if score is not None:
                label += f"  •  score: {score}"
            if is_sel:
                label = "★ " + label

            parts.append(_box(
                x, y, row["node_w"], node_h,
                label, branch,
                highlight=is_sel,
                pruned=(not is_sel and lvl_idx < num_levels - 1),
            ))

    # Leaf nodes
    if has_leaves:
        for j, lf in enumerate(leaves):
            parts.append(_box(
                leaf_positions[j][0], leaf_y_pos, lw, leaf_h,
                f"Subtheme {j+1}", lf, leaf=True,
            ))

    svg = (
        f'<div style="font-family:\'Amazon Ember Display\',\'Noto Sans Display\','
        "'Helvetica Neue',Arial,sans-serif;\">"
        f'<h4 style="color:{_ROYAL};margin:0 0 8px 0;">🌳 {_html.escape(title)}</h4>'
        f'<svg viewBox="0 0 {W} {H:.0f}" width="100%" style="max-width:{W}px;background:{_CREAM};'
        f'border-radius:12px;padding:8px;">'
        f'<defs>{markers}</defs>{"".join(parts)}</svg>'
        f'<p style="font-size:13px;color:{_MEDIUM};margin:8px 0 0 0;">'
        f'At each level, candidates are scored and pruned (greyed out). '
        f'Highlighted nodes survive to the next level. The final winner is expanded into subthemes.</p>'
        f'</div>'
    )
    display(HTML(svg))
