"""
widgets.py — Interactive ipywidgets for the FLUF2 course labs.

These build small control panels (dropdowns, sliders, a Run button) so learners
can experiment with model/parameter choices and see cost, latency, and quality
change live. Each widget uses an explicit **Run button** rather than firing on
every control change — this avoids spamming Bedrock with an API call on each
slider tick.

Each builder takes the notebook's `bedrock_runtime` client as its first argument
so the module stays decoupled from notebook globals.

Usage in a notebook:
    from mlu_utils.widgets import compression_widget
    compression_widget(bedrock_runtime, LONG_DOCUMENT)
"""

import json
import time

import ipywidgets as widgets
from IPython.display import display, clear_output

# Pricing per 1M tokens (us-west-2, approx.) used for live cost readouts
PRICING = {
    "us.amazon.nova-micro-v1:0": {"input": 0.035, "output": 0.14, "name": "Nova Micro"},
    "us.amazon.nova-lite-v1:0": {"input": 0.06, "output": 0.24, "name": "Nova Lite"},
    "us.anthropic.claude-haiku-4-5-20251001-v1:0": {"input": 0.80, "output": 4.00, "name": "Claude Haiku"},
    "us.anthropic.claude-sonnet-4-5-20250929-v1:0": {"input": 3.00, "output": 15.00, "name": "Claude Sonnet"},
}


def _cost(model_id, usage):
    p = PRICING[model_id]
    return (usage["inputTokens"] * p["input"] + usage["outputTokens"] * p["output"]) / 1e6


# ---------------------------------------------------------------------------
# Lab 1 — Cost & speed explorer
# ---------------------------------------------------------------------------
def cost_explorer_widget(bedrock_runtime, default_prompt=""):
    """Dropdown (model) + prompt box + max_tokens slider → live cost/latency.

    Args:
        bedrock_runtime: a boto3 bedrock-runtime client.
        default_prompt: text to prefill the prompt box.
    """
    model_dd = widgets.Dropdown(
        options=[(PRICING[m]["name"], m) for m in [
            "us.amazon.nova-micro-v1:0",
            "us.anthropic.claude-haiku-4-5-20251001-v1:0",
            "us.anthropic.claude-sonnet-4-5-20250929-v1:0",
        ]],
        description="Model:",
    )
    prompt_box = widgets.Textarea(
        value=default_prompt, description="Prompt:",
        layout=widgets.Layout(width="100%", height="120px"),
    )
    max_tokens = widgets.IntSlider(value=300, min=50, max=1000, step=50, description="max_tokens:")
    run_btn = widgets.Button(description="Invoke model", button_style="primary", icon="play")
    out = widgets.Output()

    def on_run(_):
        with out:
            clear_output()
            print(f"Invoking {PRICING[model_dd.value]['name']}...")
            start = time.time()
            resp = bedrock_runtime.converse(
                modelId=model_dd.value,
                messages=[{"role": "user", "content": [{"text": prompt_box.value}]}],
                inferenceConfig={"maxTokens": max_tokens.value, "temperature": 0.1},
            )
            elapsed = time.time() - start
            usage = resp["usage"]
            text = resp["output"]["message"]["content"][0]["text"]
            print(f"⏱️  Latency: {elapsed:.2f}s")
            print(f"🔢 Tokens — input: {usage['inputTokens']}, output: {usage['outputTokens']}")
            print(f"💰 Cost: ${_cost(model_dd.value, usage):.6f}")
            print("─" * 60)
            print(text[:100] + ("..." if len(text) > 100 else ""))

    run_btn.on_click(on_run)
    display(widgets.VBox([model_dd, prompt_box, max_tokens, run_btn, out]))


# ---------------------------------------------------------------------------
# Lab 5 — Compression explorer
# ---------------------------------------------------------------------------
def compression_widget(bedrock_runtime, long_document,
                       analyzer_model="us.anthropic.claude-sonnet-4-5-20250929-v1:0"):
    """Compressor-model dropdown + aggressiveness slider → compression + cost.

    Compresses `long_document` with a cheap model, then analyzes the compressed
    text with the (expensive) analyzer model, and reports token/cost savings vs
    sending the full document directly.

    Args:
        bedrock_runtime: a boto3 bedrock-runtime client.
        long_document: the text to compress.
        analyzer_model: the expensive model that does the downstream analysis.
    """
    compressor_dd = widgets.Dropdown(
        options=[(PRICING[m]["name"], m) for m in [
            "us.amazon.nova-micro-v1:0",
            "us.amazon.nova-lite-v1:0",
            "us.anthropic.claude-haiku-4-5-20251001-v1:0",
        ]],
        description="Compressor:",
    )
    # Aggressiveness controls how tight the compression target is
    aggressiveness = widgets.SelectionSlider(
        options=["light", "balanced", "aggressive"], value="balanced",
        description="Level:",
    )
    run_btn = widgets.Button(description="Compress & analyze", button_style="primary", icon="compress")
    out = widgets.Output()

    target = {
        "light": "Keep all key facts; remove only pleasantries and obvious filler.",
        "balanced": "Remove redundancy, pleasantries, and repetition. Preserve dates, amounts, IDs, actions, and status.",
        "aggressive": "Distill to the absolute minimum: only the facts required to act. Bullet points, no prose.",
    }

    def on_run(_):
        with out:
            clear_output()
            comp_model = compressor_dd.value
            print(f"Compressing with {PRICING[comp_model]['name']} ({aggressiveness.value})...")
            instruction = (f"Compress the following support content. {target[aggressiveness.value]} "
                           f"Output only the compressed version.\n\n{long_document}")
            comp_resp = bedrock_runtime.converse(
                modelId=comp_model,
                messages=[{"role": "user", "content": [{"text": instruction}]}],
                inferenceConfig={"maxTokens": 500},
            )
            compressed = comp_resp["output"]["message"]["content"][0]["text"]
            comp_cost = _cost(comp_model, comp_resp["usage"])

            # Analyze compressed vs direct
            analysis_prompt = f"Analyze this support case and recommend resolution:\n\n{compressed}"
            an_resp = bedrock_runtime.converse(
                modelId=analyzer_model,
                messages=[{"role": "user", "content": [{"text": analysis_prompt}]}],
                inferenceConfig={"maxTokens": 300},
            )
            an_cost = _cost(analyzer_model, an_resp["usage"])

            direct_prompt = f"Analyze this support case and recommend resolution:\n\n{long_document}"
            direct_resp = bedrock_runtime.converse(
                modelId=analyzer_model,
                messages=[{"role": "user", "content": [{"text": direct_prompt}]}],
                inferenceConfig={"maxTokens": 300},
            )
            direct_cost = _cost(analyzer_model, direct_resp["usage"])

            compressed_total = comp_cost + an_cost
            ratio = (1 - len(compressed) / len(long_document)) * 100
            savings = (1 - compressed_total / direct_cost) * 100 if direct_cost else 0

            print(f"📏 Text reduced {ratio:.0f}%  ({len(long_document)} → {len(compressed)} chars)")
            print(f"💰 Direct analysis cost:     ${direct_cost:.6f}")
            print(f"💰 Compress + analyze cost:  ${compressed_total:.6f} "
                  f"(compress ${comp_cost:.6f} + analyze ${an_cost:.6f})")
            print(f"💰 Net savings: {savings:.1f}%")
            print("─" * 60)
            print("Compressed document:\n")
            print(compressed[:600])

    run_btn.on_click(on_run)
    display(widgets.VBox([
        widgets.HTML("<b>Try different compressor models and aggressiveness levels:</b>"),
        compressor_dd, aggressiveness, run_btn, out,
    ]))


# ---------------------------------------------------------------------------
# Lab 6 — Cascade confidence-threshold explorer
# ---------------------------------------------------------------------------
def cascade_threshold_widget(bedrock_runtime, tickets, queue_to_category,
                             cheap_model="us.amazon.nova-micro-v1:0",
                             expensive_model="us.anthropic.claude-sonnet-4-5-20250929-v1:0"):
    """Confidence-threshold slider → escalation rate, cost, and accuracy.

    Runs a cascade over `tickets`: the cheap model classifies with a self-reported
    confidence; tickets below the threshold escalate to the expensive model. Shows
    how the threshold trades cost against accuracy.

    Args:
        bedrock_runtime: a boto3 bedrock-runtime client.
        tickets: list of dicts with subject, body, queue.
        queue_to_category: dict mapping dataset queue -> consolidated category.
    """
    categories = sorted(set(queue_to_category.values()))
    threshold = widgets.FloatSlider(value=0.8, min=0.0, max=1.0, step=0.05,
                                    description="Threshold:", readout_format=".2f")
    n_slider = widgets.IntSlider(value=10, min=5, max=min(20, len(tickets)), step=1,
                                 description="# tickets:")
    run_btn = widgets.Button(description="Run cascade", button_style="primary", icon="play")
    out = widgets.Output()

    def classify_cheap(ticket):
        prompt = (f'Classify this support ticket. Respond ONLY with JSON: '
                  f'{{"category": "{"|".join(categories)}", "confidence": 0.0-1.0}}\n\n'
                  f"Subject: {ticket['subject']}\nBody: {ticket['body']}")
        resp = bedrock_runtime.converse(
            modelId=cheap_model,
            messages=[{"role": "user", "content": [{"text": prompt}]}],
            inferenceConfig={"maxTokens": 40, "temperature": 0.0},
        )
        text = resp["output"]["message"]["content"][0]["text"]
        cost = _cost(cheap_model, resp["usage"])
        try:
            parsed = json.loads(text)
            cat = parsed.get("category", "").lower()
            conf = float(parsed.get("confidence", 0.0))
        except (json.JSONDecodeError, ValueError):
            cat, conf = "", 0.0
        for c in categories:
            if c in cat:
                cat = c
                break
        return cat, conf, cost

    def classify_expensive(ticket):
        cat_list = ", ".join(categories)
        prompt = (f"Classify this support ticket into exactly one category: {cat_list}. "
                  f"Respond with only the category word.\n\n"
                  f"Subject: {ticket['subject']}\nBody: {ticket['body']}")
        resp = bedrock_runtime.converse(
            modelId=expensive_model,
            messages=[{"role": "user", "content": [{"text": prompt}]}],
            inferenceConfig={"maxTokens": 10, "temperature": 0.0},
        )
        text = resp["output"]["message"]["content"][0]["text"].lower()
        cost = _cost(expensive_model, resp["usage"])
        pred = next((c for c in categories if c in text), text)
        return pred, cost

    def on_run(_):
        with out:
            clear_output()
            sample = tickets[:n_slider.value]
            th = threshold.value
            print(f"Running cascade on {len(sample)} tickets at threshold {th:.2f}...\n")
            correct = escalations = 0
            total_cost = 0.0
            for t in sample:
                truth = queue_to_category[t["queue"]]
                cat, conf, c_cost = classify_cheap(t)
                total_cost += c_cost
                pred = cat
                if conf < th:
                    escalations += 1
                    pred, e_cost = classify_expensive(t)
                    total_cost += e_cost
                if pred == truth:
                    correct += 1
            n = len(sample)
            print(f"⬆️  Escalated to expensive model: {escalations}/{n} ({escalations/n*100:.0f}%)")
            print(f"🎯 Accuracy vs ground truth:       {correct}/{n} ({correct/n*100:.0f}%)")
            print(f"💰 Total cost:                     ${total_cost:.6f}")
            print(f"\n💡 Raise the threshold → more escalations → higher cost but usually higher")
            print(f"   accuracy. Lower it → cheaper but riskier. Find the knee of the curve.")

    run_btn.on_click(on_run)
    display(widgets.VBox([
        widgets.HTML("<b>Tune the escalation threshold and watch cost vs accuracy move:</b>"),
        threshold, n_slider, run_btn, out,
    ]))


# ---------------------------------------------------------------------------
# Generic — scrollable rendered-markdown viewer
# ---------------------------------------------------------------------------
def markdown_viewer(md_text, height="400px", title=None):
    """Render markdown inside a fixed-height, scrollable box.

    Useful for showing long static content (e.g. the cached system prompt / SOPs)
    without taking over the whole notebook.

    Args:
        md_text: the markdown string to render.
        height: CSS height of the scrollable area (e.g. "400px").
        title: optional bold heading shown above the box.
    """
    from IPython.display import Markdown, display

    out = widgets.Output(layout=widgets.Layout(
        height=height, overflow="auto",
        border="1px solid #d0d0e0", padding="10px 16px",
        background_color="#fafafe",
    ))
    with out:
        display(Markdown(md_text))

    children = []
    if title:
        children.append(widgets.HTML(f"<b style='color:#8E6694'>{title}</b>"))
    children.append(out)
    display(widgets.VBox(children))


# ---------------------------------------------------------------------------
# Lab 5 — Selective removal diff viewer
# ---------------------------------------------------------------------------
def selective_removal_widget(text):
    """Interactive widget: custom removal list with side-by-side before/after view.

    Shows a textarea where the user adds words/phrases to remove (one per line),
    an "Apply removal" button, and two side-by-side panels showing the original
    (with removals highlighted in red) and the cleaned text.

    Args:
        text: the raw input text to apply selective removal to.
    """
    import re
    from IPython.display import display, HTML as IPHTML

    HIGHLIGHT_COLOR = "#FF6B6B"

    default_custom = ("please\ngreatly appreciate\nwould be grateful\n"
                      "thank you in advance\nI hope this finds you well\n"
                      "sorry for the inconvenience\nkind regards\nbest regards")

    custom_input = widgets.Textarea(
        value=default_custom,
        description="",
        placeholder="Add words/phrases to remove (one per line)...",
        layout=widgets.Layout(width="100%", height="120px"),
    )
    run_btn = widgets.Button(description="Apply removal", button_style="primary", icon="scissors")
    out = widgets.Output()

    def render_diff(_=None):
        with out:
            clear_output(wait=True)

            # Build patterns from user's custom word list
            custom_words = [w.strip() for w in custom_input.value.split("\n") if w.strip()]
            all_patterns = []
            for word in custom_words:
                escaped = re.escape(word)
                all_patterns.append(rf"(?i)\b{escaped}\b")

            # Find all matches
            removals = []
            for pattern in all_patterns:
                try:
                    for m in re.finditer(pattern, text):
                        if m.group():
                            removals.append((m.start(), m.end(), m.group()))
                except re.error:
                    continue

            # Sort and merge overlapping
            removals.sort(key=lambda x: x[0])
            merged = []
            for start, end, txt in removals:
                if merged and start <= merged[-1][1]:
                    merged[-1] = (merged[-1][0], max(end, merged[-1][1]), merged[-1][2])
                else:
                    merged.append((start, end, txt))

            # Build cleaned text
            cleaned_parts = []
            prev_end = 0
            for start, end, _ in merged:
                cleaned_parts.append(text[prev_end:start])
                prev_end = end
            cleaned_parts.append(text[prev_end:])
            cleaned = "".join(cleaned_parts)
            cleaned = re.sub(r"\n{3,}", "\n\n", cleaned)
            cleaned = re.sub(r"[ \t]+", " ", cleaned).strip()

            # Build highlighted original HTML
            html_parts = []
            prev_end = 0
            for start, end, _ in merged:
                if start > prev_end:
                    html_parts.append(_escape_html(text[prev_end:start]))
                removed = text[start:end]
                html_parts.append(
                    f'<span style="background-color: {HIGHLIGHT_COLOR}; '
                    f'text-decoration: line-through; padding: 1px 2px; '
                    f'border-radius: 2px; color: #333;">{_escape_html(removed)}</span>'
                )
                prev_end = end
            if prev_end < len(text):
                html_parts.append(_escape_html(text[prev_end:]))
            highlighted_original = "".join(html_parts)

            # Stats
            chars_removed = sum(end - start for start, end, _ in merged)
            original_chars = len(text)
            cleaned_chars = len(cleaned)
            reduction_pct = (1 - cleaned_chars / original_chars) * 100 if original_chars else 0

            widget_html = f"""
            <div style="margin: 10px 0;">
                <div style="display: flex; gap: 20px; align-items: stretch;">
                    <div style="flex: 1; border: 1px solid #D9CCDB; border-radius: 5px; overflow: hidden;">
                        <div style="background-color: #8E6694; color: white; padding: 8px 12px; font-weight: bold;">
                            📄 Original Text ({original_chars:,} chars)
                        </div>
                        <div style="padding: 12px; max-height: 400px; overflow-y: auto;
                                    font-family: monospace; font-size: 12px; line-height: 1.6;
                                    white-space: pre-wrap; word-wrap: break-word;">
{highlighted_original}
                        </div>
                    </div>
                    <div style="flex: 1; border: 1px solid #D9CCDB; border-radius: 5px; overflow: hidden;">
                        <div style="background-color: #8E6694; color: white; padding: 8px 12px; font-weight: bold;">
                            ✂️ After Removal ({cleaned_chars:,} chars)
                        </div>
                        <div style="padding: 12px; max-height: 400px; overflow-y: auto;
                                    font-family: monospace; font-size: 12px; line-height: 1.6;
                                    white-space: pre-wrap; word-wrap: break-word;">
{_escape_html(cleaned)}
                        </div>
                    </div>
                </div>
                <div style="margin-top: 10px; padding: 10px 15px; background-color: #F0EBF1;
                            border-radius: 5px; display: flex; gap: 30px; align-items: center; flex-wrap: wrap;">
                    <span><strong>Removed:</strong> {chars_removed:,} chars ({reduction_pct:.1f}%)</span>
                    <span><strong>Matches:</strong> {len(merged)} hits</span>
                    <span><strong>Custom words:</strong> {len(custom_words)}</span>
                    <span style="display: inline-flex; align-items: center; gap: 5px;">
                        <span style="display: inline-block; width: 14px; height: 14px;
                                     background-color: {HIGHLIGHT_COLOR}; border-radius: 2px;"></span>
                        = removed
                    </span>
                </div>
            </div>
            """
            display(IPHTML(widget_html))

    run_btn.on_click(render_diff)

    display(widgets.VBox([
        widgets.HTML("<b>✂️ Removal list</b> (one word or phrase per line):"),
        custom_input,
        run_btn,
        out,
    ]))

    # Initial render (after widget is displayed, so output appears below controls)
    render_diff()



def _escape_html(text):
    """Escape HTML special characters for safe rendering."""
    return (text
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace('"', "&quot;")
            .replace("\n", "<br>"))
