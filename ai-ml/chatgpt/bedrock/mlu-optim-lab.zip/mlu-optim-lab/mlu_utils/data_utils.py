"""Data loading utilities for the FLUF2 course labs."""

import json


# Load tickets from the Tobi-Bueck/customer-support-tickets dataset
def load_tickets(path="data/support_tickets.jsonl", n=None):
    """Load real support tickets with ground-truth labels."""
    tickets = []
    with open(path) as f:
        for line in f:
            tickets.append(json.loads(line))
    return tickets[:n] if n else tickets
