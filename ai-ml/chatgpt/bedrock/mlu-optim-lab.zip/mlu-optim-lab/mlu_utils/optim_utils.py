"""
optim_utils.py — Visualization helpers for the FLUF2 course
(Optimizing Generative AI Applications on Amazon Bedrock).

Each function takes the data a lab already computes and renders a Plotly chart.
Plotly uses the "notebook_connected" renderer so notebooks stay small (plotly.js
loads from a CDN rather than being embedded).

Usage in a notebook:
    from mlu_utils.optim_utils import plot_model_comparison
    plot_model_comparison(results)
"""

import json
import random
import time

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import plotly.io as pio
from tabulate import tabulate

# Load plotly.js from CDN so executed notebooks stay small on disk
pio.renderers.default = "notebook_connected"

# MLU brand palette
GOLD = "#FFBB45"
GOLD_LIGHT = "#FFC96A"
GOLD_MED = "#FFD68F"
GOLD_PALE = "#FFE4B5"
GOLD_WASH = "#FFF1DA"

PLUM = "#8E6694"
PLUM_LIGHT = "#B499B8"
PLUM_PALE = "#D9CCDB"
PLUM_WASH = "#F0EBF1"

# Backward-compatible aliases used throughout the file
CYAN = GOLD_LIGHT
PURPLE = PLUM
PINK = GOLD
SEQ3 = [GOLD, PLUM, GOLD_MED]

# Default layout for all Plotly charts: light background, no tilted labels
_LAYOUT_DEFAULTS = dict(
    plot_bgcolor="#EDECED",
    paper_bgcolor="#EDECED",
    xaxis_tickangle=0,
)
pio.templates["mlu"] = go.layout.Template(layout=go.Layout(**_LAYOUT_DEFAULTS))
pio.templates.default = "mlu"


def styled_table(df, caption="", bar_cols=None, fmt=None, center=False):
    """Apply brand styling to a DataFrame and display it.

    Args:
        df: pandas DataFrame to style.
        caption: optional table caption string.
        bar_cols: dict of {column_name: color} to apply bar styling.
                  If None, no bars are drawn.
        fmt: dict of {column_name: format_string} for number formatting.
             If None, no formatting is applied.
        center: if True, center-align headers and cell values.

    Returns:
        The styled DataFrame (also displayed via IPython.display).
    """
    from IPython.display import display

    styler = df.style.hide(axis="index")
    if bar_cols:
        for col, color in bar_cols.items():
            if col in df.columns:
                styler = styler.bar(subset=[col], color=color)
    if fmt:
        styler = styler.format(fmt)
    text_align = "center" if center else "left"
    styler = styler.set_caption(caption).set_table_styles([
        {"selector": "", "props": [("width", "100%")]},
        {"selector": "caption", "props": [("font-size", "14px"), ("font-weight", "bold"),
                                          ("color", "#43004d"), ("text-align", "left"),
                                          ("padding-bottom", "6px")]},
        {"selector": "th", "props": [("background-color", "#43004d"), ("color", "white"),
                                     ("text-align", text_align), ("padding", "6px 10px")]},
        {"selector": "td", "props": [("padding", "4px 10px"), ("text-align", text_align)]},
    ])
    display(styler)
    return styler


def render_output(text, title=None, color="#999", bg="#f5f5f5"):
    """Render markdown text inside a styled box.

    Args:
        text: markdown-formatted string to render.
        title: optional bold title line above the content.
        color: left border accent color (default grey).
        bg: background color (default light grey).
    """
    from IPython.display import display, HTML
    import textwrap

    # Convert basic markdown to HTML (bold, italic, code, links)
    import re
    html = text
    html = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', html)
    html = re.sub(r'\*(.+?)\*', r'<em>\1</em>', html)
    html = re.sub(r'`(.+?)`', r'<code style="background:#e8e8e8;padding:1px 4px;border-radius:3px">\1</code>', html)
    html = re.sub(r'\[(.+?)\]\((.+?)\)', r'<a href="\2" style="color:#693371">\1</a>', html)
    html = html.replace('\n', '<br>')

    title_html = f'<strong style="color:#43004d;">{title}</strong><br>' if title else ""

    display(HTML(f"""
    <div style="background:{bg}; border-left:4px solid {color}; border-radius:6px;
                padding:14px 18px; margin:12px 0; font-size:14px; color:#1f0024;">
    {title_html}{html}
    </div>
    """))


# ---------------------------------------------------------------------------
# Lab 1 — Prompt optimization & tier exploration
# ---------------------------------------------------------------------------
def style_comparison(df):
    """Style a model comparison DataFrame with color-coded cost and latency.

    Highlights the cheapest/fastest in green and most expensive/slowest in red.
    Expects columns: "Model", "Cost ($)", "Latency (s)", and optionally "vs Cheapest".

    Args:
        df: pandas DataFrame with model comparison data.

    Returns:
        The styled DataFrame (also displayed via IPython.display).
    """
    from IPython.display import display

    # Uppercase all column headers
    df = df.rename(columns={c: c.upper() for c in df.columns})

    cost_col = df["COST ($)"]
    cost_min, cost_max = cost_col.min(), cost_col.max()

    def color_cost(val):
        if val == cost_min:
            return "background-color: #d4edda; color: #155724; font-weight: bold"
        elif val == cost_max:
            return "background-color: #f8d7da; color: #721c24; font-weight: bold"
        return ""

    def color_latency(val):
        if val == df["LATENCY (S)"].min():
            return "background-color: #d4edda; color: #155724; font-weight: bold"
        elif val == df["LATENCY (S)"].max():
            return "background-color: #f8d7da; color: #721c24; font-weight: bold"
        return ""

    fmt = {"COST ($)": "${:.6f}", "LATENCY (S)": "{:.2f}"}
    if "VS CHEAPEST" in df.columns:
        fmt["VS CHEAPEST"] = "{}"

    styled = df.style\
        .format(fmt)\
        .map(color_cost, subset=["COST ($)"])\
        .map(color_latency, subset=["LATENCY (S)"])\
        .set_properties(**{"text-align": "center"})\
        .set_properties(subset=["MODEL"], **{"text-align": "left", "font-weight": "bold"})\
        .set_table_styles([
            {"selector": "", "props": [("width", "100%")]},
            {"selector": "th", "props": [
                ("background-color", "#43004d"), ("color", "white"),
                ("padding", "8px 12px"), ("text-align", "center"), ("font-size", "13px")
            ]},
            {"selector": "td", "props": [("padding", "8px 12px"), ("font-size", "13px")]},
            {"selector": "tr:hover", "props": [("background-color", "#f0ebf1")]},
        ])\
        .hide(axis="index")

    display(styled)
    return styled


def plot_model_comparison(results):
    """Bar charts of cost (log scale) and latency across models.

    Args:
        results: list of dicts with keys model, cost_usd, latency_s,
                 input_tokens, output_tokens.
    """
    chart_df = pd.DataFrame([{
        "Model": r["model"],
        "Cost ($)": r["cost_usd"],
        "Latency (s)": r["latency_s"],
        "Input Tokens": r["input_tokens"],
        "Output Tokens": r["output_tokens"],
    } for r in results])

    fig = px.bar(chart_df, x="Model", y="Cost ($)", color="Model", text="Cost ($)",
                 title="Cost per Request by Model",
                 color_discrete_sequence=SEQ3)
    fig.update_traces(texttemplate="$%{y:.6f}", textposition="outside")
    max_cost = chart_df["Cost ($)"].max()
    fig.update_yaxes(range=[0, max_cost * 1.3])
    fig.update_layout(showlegend=False, height=400, margin=dict(t=50))
    fig.show()

    fig2 = px.bar(chart_df, x="Model", y="Latency (s)", color="Model", text="Latency (s)",
                  title="Latency by Model", color_discrete_sequence=SEQ3)
    fig2.update_traces(texttemplate="%{y:.2f}s", textposition="outside")
    max_lat = chart_df["Latency (s)"].max()
    fig2.update_yaxes(range=[0, max_lat + 1])
    fig2.update_layout(showlegend=False, height=400, margin=dict(t=50))
    fig2.show()



# ---------------------------------------------------------------------------
# Lab 2 — Prompt caching
# ---------------------------------------------------------------------------
def print_cache_summary(results, title="Cache Summary"):
    """Print a styled summary of cache performance results.

    Args:
        results: list of dicts with keys "Query #", "Cache Status", "Latency (s)",
                 "Cost with cache ($)", "Cost without cache ($)".
        title: header string for the summary.
    """
    n = len(results)
    hits = sum(1 for r in results if "HIT" in r["Cache Status"])
    writes = sum(1 for r in results if "WRITE" in r["Cache Status"])
    misses = sum(1 for r in results if "MISS" in r["Cache Status"])
    total_cost_with = sum(r["Cost with cache ($)"] for r in results)
    total_cost_without = sum(r["Cost without cache ($)"] for r in results)
    savings = total_cost_without - total_cost_with
    savings_pct = (savings / total_cost_without * 100) if total_cost_without > 0 else 0
    avg_latency = sum(r["Latency (s)"] for r in results) / n if n > 0 else 0

    print(f"\n{'='*60}")
    print(f"📊 {title}")
    print(f"{'='*60}")
    print(f"  Queries:      {n}")
    print(f"  Cache HITs:   {hits} ({hits/n*100:.0f}%)" if n > 0 else "  Cache HITs:   0")
    print(f"  Cache WRITEs: {writes}")
    print(f"  Cache MISSes: {misses}")
    print(f"  Avg latency:  {avg_latency:.2f}s")
    print(f"  Total cost (with cache):    ${total_cost_with:.4f}")
    print(f"  Total cost (without cache): ${total_cost_without:.4f}")
    print(f"  Savings: ${savings:.4f} ({savings_pct:.1f}%)")
    print(f"{'='*60}\n")


def plot_cache_performance(detailed_results, pause_after_query=None):
    """Dual-axis view across many requests: cost per query (with vs without caching)
    on the left axis, latency on the right axis, with an optional cache-expiry marker.

    Args:
        detailed_results: list of dicts with keys "Query #", "Latency (s)",
            "Cost with cache ($)", "Cost without cache ($)", "Cache Status" (numeric costs).
        pause_after_query: query number after which a cache-expiry pause happened
            (draws a vertical marker). Pass None to skip.
    """
    df = pd.DataFrame(detailed_results)

    fig = go.Figure()
    # Left axis: cost per query — baseline (no cache) vs actual (with cache)
    fig.add_trace(go.Scatter(
        x=df["Query #"], y=df["Cost without cache ($)"],
        name="Cost without caching (baseline)", mode="lines+markers",
        line=dict(color=PINK, dash="dash"),
    ))
    fig.add_trace(go.Scatter(
        x=df["Query #"], y=df["Cost with cache ($)"],
        name="Cost with caching", mode="lines+markers", line=dict(color="#B499B8"),
    ))
    # Right (secondary) axis: latency per query
    fig.add_trace(go.Scatter(
        x=df["Query #"], y=df["Latency (s)"],
        name="Latency (s)", mode="lines+markers",
        line=dict(color="#2E6171", dash="dot"), yaxis="y2",
    ))
    fig.update_layout(
        title="Cache Performance: Cost & Latency per Query",
        xaxis_title="Query #",
        yaxis=dict(title="Cost per query ($)"),
        yaxis2=dict(title="Latency (s)", overlaying="y", side="right"),
        height=460, legend=dict(x=0.02, y=0.98, bgcolor="rgba(255,255,255,0.6)"),
    )
    # Add baseline latency reference (first request = no cache benefit)
    if len(df) > 1:
        first_latency = df["Latency (s)"].iloc[0]
        fig.add_hline(y=first_latency, line_dash="dash", line_color="#2E6171",
                      opacity=0.4, yref="y2",
                      annotation_text=f"Cold start latency ({first_latency:.1f}s)",
                      annotation_position="top right",
                      annotation_font_color="#2E6171")
    if pause_after_query is not None:
        fig.add_vline(x=pause_after_query + 0.5, line_dash="dash", line_color="gray")
        fig.add_annotation(x=pause_after_query + 0.5, yref="paper", y=1.0,
                           text="5-min pause → cache expires", showarrow=False,
                           font=dict(color="gray"), xanchor="left")
    fig.show()



# ---------------------------------------------------------------------------
# Lab 3 — Resilience & observability
# ---------------------------------------------------------------------------
def plot_backoff_jitter(n_attempts=6, n_clients=20, seed=None):
    """Scatter plot contrasting exponential backoff with and without jitter.

    Args:
        n_attempts: number of retry attempts to simulate.
        n_clients: number of jittered client trajectories to draw.
        seed: optional RNG seed for reproducibility.
    """
    if seed is not None:
        random.seed(seed)

    no_jitter = [2 ** a for a in range(n_attempts)]

    fig = go.Figure()
    for _ in range(n_clients):
        delays = [(2 ** a) * (1 + random.uniform(-0.25, 0.25)) for a in range(n_attempts)]
        fig.add_trace(go.Scatter(
            x=list(range(1, n_attempts + 1)), y=delays,
            mode="markers", marker=dict(color=PLUM_LIGHT, size=8, opacity=0.5),
            showlegend=False, hoverinfo="skip",
        ))
    fig.add_trace(go.Scatter(
        x=list(range(1, n_attempts + 1)), y=no_jitter,
        mode="markers+lines", name="No jitter (all clients aligned)",
        marker=dict(color=GOLD, size=12),
        line=dict(color=GOLD, width=3, dash="dash"),
    ))
    fig.update_layout(
        title=f"Exponential Backoff: Without Jitter vs With Jitter ({n_clients} clients)",
        xaxis_title="Retry attempt", yaxis_title="Delay before retry (s)",
        height=450, legend=dict(x=0.02, y=0.98),
    )
    fig.show()


# ---------------------------------------------------------------------------
# Lab 4 — Cross-region inference
# ---------------------------------------------------------------------------
def plot_throughput_comparison(single_results, cross_results):
    """Bar chart of throughput: single-region vs cross-region.

    Args:
        single_results, cross_results: dicts with keys throughput_rps, avg_latency_s.
    """
    tp_df = pd.DataFrame([
        {"Profile": "Single-region", "Throughput (req/s)": single_results["throughput_rps"]},
        {"Profile": "Cross-region", "Throughput (req/s)": cross_results["throughput_rps"]},
    ])
    fig = px.bar(tp_df, x="Profile", y="Throughput (req/s)", color="Profile",
                 text="Throughput (req/s)",
                 title="Concurrent Throughput: Single-Region vs Cross-Region",
                 color_discrete_sequence=[PINK, PURPLE])
    fig.update_traces(texttemplate="%{y:.1f} req/s", textposition="outside")
    fig.update_layout(showlegend=False, height=450, margin=dict(t=80, b=40),
                      yaxis=dict(range=[0, max(single_results["throughput_rps"], cross_results["throughput_rps"]) * 1.25]))
    fig.show()


def plot_latency_distribution(single_latencies, cross_latencies):
    """Box plot of per-request latency: single-region vs cross-region.

    Args:
        single_latencies, cross_latencies: lists of per-call latency floats.
    """
    lat_df = pd.DataFrame({
        "Single-region": single_latencies,
        "Cross-region": cross_latencies,
    })
    lat_long = lat_df.melt(var_name="Profile", value_name="Latency (s)")
    fig = px.box(lat_long, x="Profile", y="Latency (s)", color="Profile", points=False,
                 title="Per-Request Latency Distribution (routing overhead)",
                 color_discrete_sequence=[PINK, CYAN])
    fig.update_layout(showlegend=False, height=400)
    fig.show()

# ---------------------------------------------------------------------------
# Lab 5 — Prompt compression
# ---------------------------------------------------------------------------
def compare_compression(compress_response, analysis_response, direct_response,
                        compress_time=None, analysis_time=None, direct_time=None,
                        pricing=None):
    """Compare direct vs compressed inference with multiple full-width styled tables.

    Displays three tables:
      1. Token Usage — input/output tokens and latency for each step
      2. Cost Breakdown — per-step and total costs for both methods
      3. Summary — compression ratio, savings, latency overhead, and verdict

    Args:
        compress_response: Converse API response from the compression step (cheap model).
        analysis_response: Converse API response from analyzing the compressed text (expensive model).
        direct_response: Converse API response from analyzing the full text directly (expensive model).
        compress_time: optional float, seconds for the compression call.
        analysis_time: optional float, seconds for the analysis call.
        direct_time: optional float, seconds for the direct call.
        pricing: optional dict with keys "compressor" and "analyzer", each containing
                 "input" and "output" per-1M-token prices. Defaults to Nova Micro + Claude Sonnet.

    Returns:
        dict with keys "token_df", "cost_df", "summary_df".
    """
    from IPython.display import display, HTML

    if pricing is None:
        pricing = {
            "compressor": {"input": 0.035, "output": 0.14},   # Nova Micro
            "analyzer": {"input": 3.00, "output": 15.00},      # Claude Sonnet
        }

    has_timing = all(t is not None for t in [compress_time, analysis_time, direct_time])

    compress_usage = compress_response["usage"]
    analysis_usage = analysis_response["usage"]
    direct_usage = direct_response["usage"]

    # Cost calculations
    compressor_cost = (
        compress_usage["inputTokens"] * pricing["compressor"]["input"] +
        compress_usage["outputTokens"] * pricing["compressor"]["output"]
    ) / 1e6
    analysis_cost = (
        analysis_usage["inputTokens"] * pricing["analyzer"]["input"] +
        analysis_usage["outputTokens"] * pricing["analyzer"]["output"]
    ) / 1e6
    compressed_total = compressor_cost + analysis_cost
    direct_cost = (
        direct_usage["inputTokens"] * pricing["analyzer"]["input"] +
        direct_usage["outputTokens"] * pricing["analyzer"]["output"]
    ) / 1e6

    savings_pct = (1 - compressed_total / direct_cost) * 100 if direct_cost else 0
    compression_ratio = (
        direct_usage["inputTokens"] / analysis_usage["inputTokens"]
        if analysis_usage["inputTokens"] else 0
    )

    # Full-width table styling (no bar highlights)
    _table_styles = [
        {"selector": "", "props": [("width", "100%"), ("border-collapse", "collapse")]},
        {"selector": "caption", "props": [("font-size", "14px"), ("font-weight", "bold"),
                                          ("color", "#43004d"), ("text-align", "left"),
                                          ("padding-bottom", "8px")]},
        {"selector": "th", "props": [("background-color", "#43004d"), ("color", "white"),
                                     ("text-align", "center"), ("padding", "8px 12px"),
                                     ("text-transform", "uppercase"), ("font-size", "12px")]},
        {"selector": "td", "props": [("padding", "6px 12px"), ("text-align", "center"),
                                     ("border-bottom", f"1px solid {PLUM_PALE}"),
                                     ("background-color", "white")]},
    ]

    # ─── Table 1: Token Usage ────────────────────────────────────────────
    token_rows = [
        {
            "Step": "📄 Direct (full → expensive model)",
            "Input Tokens": direct_usage["inputTokens"],
            "Output Tokens": direct_usage["outputTokens"],
            "Total Tokens": direct_usage["inputTokens"] + direct_usage["outputTokens"],
        },
        {
            "Step": "💻 Compress (full → cheap model)",
            "Input Tokens": compress_usage["inputTokens"],
            "Output Tokens": compress_usage["outputTokens"],
            "Total Tokens": compress_usage["inputTokens"] + compress_usage["outputTokens"],
        },
        {
            "Step": "🔍 Analyze (compressed → expensive model)",
            "Input Tokens": analysis_usage["inputTokens"],
            "Output Tokens": analysis_usage["outputTokens"],
            "Total Tokens": analysis_usage["inputTokens"] + analysis_usage["outputTokens"],
        },
    ]
    if has_timing:
        token_rows[0]["Latency (s)"] = direct_time
        token_rows[1]["Latency (s)"] = compress_time
        token_rows[2]["Latency (s)"] = analysis_time

    token_df = pd.DataFrame(token_rows)
    fmt1 = {"Input Tokens": "{:,}", "Output Tokens": "{:,}", "Total Tokens": "{:,}"}
    if has_timing:
        fmt1["Latency (s)"] = "{:.2f}"
    styler1 = (token_df.style.hide(axis="index")
               .set_caption("① Token Usage by Step")
               .set_table_styles(_table_styles)
               .format(fmt1))
    display(styler1)
    display(HTML("<div style='margin-top: 40px;'></div>"))

    # ─── Table 2: Cost Breakdown ─────────────────────────────────────────
    min_total_cost = min(direct_cost, compressed_total)
    cost_df = pd.DataFrame([
        {
            "Method": "Direct",
            "Step": "Full doc → Expensive model",
            "Input Cost ($)": direct_usage["inputTokens"] * pricing["analyzer"]["input"] / 1e6,
            "Output Cost ($)": direct_usage["outputTokens"] * pricing["analyzer"]["output"] / 1e6,
            "Step Cost ($)": direct_cost,
            "Total Cost ($)": direct_cost,
            "vs Cheapest": direct_cost / min_total_cost if min_total_cost else 0,
        },
        {
            "Method": "Compressed",
            "Step": "Full doc → Cheap model (compress)",
            "Input Cost ($)": compress_usage["inputTokens"] * pricing["compressor"]["input"] / 1e6,
            "Output Cost ($)": compress_usage["outputTokens"] * pricing["compressor"]["output"] / 1e6,
            "Step Cost ($)": compressor_cost,
            "Total Cost ($)": compressed_total,
            "vs Cheapest": compressed_total / min_total_cost if min_total_cost else 0,
        },
        {
            "Method": "Compressed",
            "Step": "Compressed → Expensive model (analyze)",
            "Input Cost ($)": analysis_usage["inputTokens"] * pricing["analyzer"]["input"] / 1e6,
            "Output Cost ($)": analysis_usage["outputTokens"] * pricing["analyzer"]["output"] / 1e6,
            "Step Cost ($)": analysis_cost,
            "Total Cost ($)": compressed_total,
            "vs Cheapest": compressed_total / min_total_cost if min_total_cost else 0,
        },
    ])
    styler2 = (cost_df.style.hide(axis="index")
               .set_caption("② Cost Breakdown")
               .set_table_styles(_table_styles)
               .format({
                   "Input Cost ($)": "${:.6f}",
                   "Output Cost ($)": "${:.6f}",
                   "Step Cost ($)": "${:.6f}",
                   "Total Cost ($)": "${:.6f}",
                   "vs Cheapest": "{:.1f}×",
               }))
    display(styler2)
    display(HTML("<div style='margin-top: 40px;'></div>"))

    # ─── Table 3: Summary ────────────────────────────────────────────────
    summary_rows = [
        {
            "Metric": "Compression Ratio",
            "Value": f"{compression_ratio:.1f}×",
        },
        {
            "Metric": "Direct Cost",
            "Value": f"${direct_cost:.6f}",
        },
        {
            "Metric": "Compressed Cost",
            "Value": f"${compressed_total:.6f}",
        },
        {
            "Metric": "💰 Cost Savings",
            "Value": f"{savings_pct:.1f}%",
        },
    ]
    if has_timing:
        compressed_latency = compress_time + analysis_time
        latency_overhead = compressed_latency - direct_time
        overhead_sign = "+" if latency_overhead >= 0 else ""
        summary_rows.extend([
            {
                "Metric": "Direct Latency",
                "Value": f"{direct_time:.2f}s",
            },
            {
                "Metric": "Compressed Latency",
                "Value": f"{compressed_latency:.2f}s",
            },
            {
                "Metric": "⏱️ Latency Overhead",
                "Value": f"{overhead_sign}{latency_overhead:.2f}s",
                
            },
        ])

    summary_df = pd.DataFrame(summary_rows)
    styler3 = (summary_df.style.hide(axis="index")
               .set_caption("③ Compression Summary")
               .set_table_styles(_table_styles))
    display(styler3)

    return {"token_df": token_df, "cost_df": cost_df, "summary_df": summary_df}


def compare_batching(bedrock_client, tickets, batch_size=10, model_id="us.amazon.nova-micro-v1:0",
                     pricing=None, max_tickets=100):
    """Compare processing tickets one-by-one vs in batches.

    Processes tickets individually and in batches, then displays a styled
    comparison table showing time, cost, and throughput differences.

    Args:
        bedrock_client: boto3 bedrock-runtime client.
        tickets: list of ticket dicts with 'subject' and 'body' keys.
        batch_size: number of tickets to aggregate per batch call.
        model_id: model to use for classification.
        pricing: optional dict with "input" and "output" per-1M-token prices.
                 Defaults to Nova Micro pricing.
        max_tickets: maximum number of tickets to process (default 100).

    Returns:
        dict with keys "summary_df", "individual_results", "batch_results".
    """
    import time
    import math
    from IPython.display import display, HTML

    if pricing is None:
        pricing = {"input": 0.035, "output": 0.14}  # Nova Micro

    tickets = tickets[:max_tickets]
    n = len(tickets)
    n_batches = math.ceil(n / batch_size)

    classify_prompt = "Classify this support ticket into a category (Billing, Technical, Account, Shipping, Other) and priority (High/Medium/Low). Respond in one line."

    # ─── Individual processing ───────────────────────────────────────────
    individual_tokens_in = 0
    individual_tokens_out = 0
    start = time.time()
    for t in tickets:
        text = f"{t['subject']}\n{t['body']}"
        resp = bedrock_client.converse(
            modelId=model_id,
            messages=[{"role": "user", "content": [{"text": f"{classify_prompt}\n\nTicket: {text}"}]}],
            inferenceConfig={"maxTokens": 50}
        )
        u = resp["usage"]
        individual_tokens_in += u["inputTokens"]
        individual_tokens_out += u["outputTokens"]
    individual_time = time.time() - start

    individual_cost = (
        individual_tokens_in * pricing["input"] +
        individual_tokens_out * pricing["output"]
    ) / 1e6

    # ─── Batched processing ──────────────────────────────────────────────
    batch_tokens_in = 0
    batch_tokens_out = 0
    start = time.time()
    for i in range(0, n, batch_size):
        chunk = tickets[i:i + batch_size]
        batch_text = ""
        for j, t in enumerate(chunk, 1):
            batch_text += f"[Ticket {j}] {t['subject']}: {t['body'][:200]}\n"

        resp = bedrock_client.converse(
            modelId=model_id,
            messages=[{"role": "user", "content": [{"text": f"{classify_prompt}\n\n{batch_text}"}]}],
            inferenceConfig={"maxTokens": 50 * len(chunk)}
        )
        u = resp["usage"]
        batch_tokens_in += u["inputTokens"]
        batch_tokens_out += u["outputTokens"]
    batch_time = time.time() - start

    batch_cost = (
        batch_tokens_in * pricing["input"] +
        batch_tokens_out * pricing["output"]
    ) / 1e6

    # ─── Full-width table styling ────────────────────────────────────────
    _table_styles = [
        {"selector": "", "props": [("width", "100%"), ("border-collapse", "collapse")]},
        {"selector": "caption", "props": [("font-size", "14px"), ("font-weight", "bold"),
                                          ("color", "#43004d"), ("text-align", "left"),
                                          ("padding-bottom", "8px")]},
        {"selector": "th", "props": [("background-color", "#43004d"), ("color", "white"),
                                     ("text-align", "center"), ("padding", "8px 12px"),
                                     ("text-transform", "uppercase"), ("font-size", "12px")]},
        {"selector": "td", "props": [("padding", "6px 12px"), ("text-align", "center"),
                                     ("border-bottom", f"1px solid {PLUM_PALE}"),
                                     ("background-color", "white")]},
    ]

    # ─── Table 1: Head-to-head comparison ────────────────────────────────
    min_cost = min(individual_cost, batch_cost)
    comp_df = pd.DataFrame([
        {
            "Method": f"Individual ({n} calls)",
            "Total Time (s)": round(individual_time, 2),
            "API Calls": n,
            "Input Tokens": individual_tokens_in,
            "Output Tokens": individual_tokens_out,
            "Cost ($)": individual_cost,
            "vs Cheapest": individual_cost / min_cost if min_cost else 0,
        },
        {
            "Method": f"Batched ({n_batches} calls, {batch_size}/batch)",
            "Total Time (s)": round(batch_time, 2),
            "API Calls": n_batches,
            "Input Tokens": batch_tokens_in,
            "Output Tokens": batch_tokens_out,
            "Cost ($)": batch_cost,
            "vs Cheapest": batch_cost / min_cost if min_cost else 0,
        },
    ])
    styler1 = (comp_df.style.hide(axis="index")
               .set_caption(f"① Batching Comparison: {n} tickets")
               .set_table_styles(_table_styles)
               .format({
                   "Total Time (s)": "{:.2f}",
                   "Cost ($)": "${:.6f}",
                   "Input Tokens": "{:,}",
                   "Output Tokens": "{:,}",
                   "vs Cheapest": "{:.1f}×",
               }))
    display(styler1)
    display(HTML("<div style='margin-top: 40px;'></div>"))

    # ─── Table 2: Summary metrics ────────────────────────────────────────
    time_savings = (1 - batch_time / individual_time) * 100 if individual_time else 0
    cost_savings = (1 - batch_cost / individual_cost) * 100 if individual_cost else 0
    speedup = individual_time / batch_time if batch_time else 0
    call_reduction = (1 - n_batches / n) * 100

    summary_df = pd.DataFrame([
        {
            "Metric": "⏱️ Time Savings",
            "Value": f"{time_savings:.0f}%",
        },
        {
            "Metric": "💰 Total Cost Savings",
            "Value": f"{cost_savings:.0f}%",
        },
        {
            "Metric": "📞 API Call Reduction",
            "Value": f"{call_reduction:.0f}%",
        },
        {
            "Metric": "🚀 Throughput",
            "Value": f"{n/batch_time:.1f} tickets/s",
        },
    ])
    styler2 = (summary_df.style.hide(axis="index")
               .set_caption("② Batching Impact Summary")
               .set_table_styles(_table_styles))
    display(styler2)

    return {
        "summary_df": summary_df,
        "individual": {"time": individual_time, "cost": individual_cost, "tokens_in": individual_tokens_in},
        "batch": {"time": batch_time, "cost": batch_cost, "tokens_in": batch_tokens_in},
    }


def selective_removal(text):
    """Strip pleasantries, repetition, and filler from text before sending to a model.

    Applies rule-based heuristics to remove common padding that adds tokens
    without adding information:
      - Greetings and sign-offs
      - Pleasantries and filler phrases
      - Repeated whitespace and blank lines
      - Common email/ticket boilerplate

    Args:
        text: raw input string (e.g., a support ticket body).

    Returns:
        dict with keys:
          - "cleaned": the stripped text
          - "original_chars": character count of original
          - "cleaned_chars": character count after removal
          - "reduction_pct": percentage of characters removed
    """
    import re

    original_chars = len(text)

    # Greeting lines
    greetings = [
        r"(?i)^(hi|hello|hey|dear|good (morning|afternoon|evening))[\s,!.]*.*\n?",
        r"(?i)^(to whom it may concern|greetings)[\s,!.]*.*\n?",
    ]
    # Sign-offs
    signoffs = [
        r"(?i)(thanks|thank you|regards|best|cheers|sincerely|kind regards|best regards|warm regards)[\s,!.]*$",
        r"(?i)(please let me know|don'?t hesitate to (reach out|contact)).*$",
        r"(?i)(looking forward to|hope to hear|appreciate your).*$",
    ]
    # Filler phrases (mid-sentence)
    fillers = [
        r"(?i)\b(I just wanted to|I was wondering if|I would like to|I am writing to)\b",
        r"(?i)\b(as you (may )?know|as mentioned (earlier|before|above))\b",
        r"(?i)\b(basically|essentially|actually|honestly|frankly|literally)\b",
        r"(?i)\b(I think that|it seems like|in my opinion|from my perspective)\b",
        r"(?i)\b(please note that|kindly|I hope this (email|message) finds you well)\b",
        r"(?i)\b(sorry (to bother|for the inconvenience|to trouble))\b",
    ]

    cleaned = text
    for pattern in greetings:
        cleaned = re.sub(pattern, "", cleaned, count=1)
    for pattern in signoffs:
        cleaned = re.sub(pattern, "", cleaned)
    for pattern in fillers:
        cleaned = re.sub(pattern, "", cleaned)

    # Collapse multiple blank lines and trim
    cleaned = re.sub(r"\n{3,}", "\n\n", cleaned)
    cleaned = re.sub(r"[ \t]+", " ", cleaned)
    cleaned = cleaned.strip()

    cleaned_chars = len(cleaned)
    reduction_pct = (1 - cleaned_chars / original_chars) * 100 if original_chars else 0

    return {
        "cleaned": cleaned,
        "original_chars": original_chars,
        "cleaned_chars": cleaned_chars,
        "reduction_pct": reduction_pct,
    }


def compare_all_compression(bedrock_client, document, model_id="us.anthropic.claude-sonnet-4-5-20250929-v1:0",
                            compressor_id="us.amazon.nova-micro-v1:0", analysis_question=None,
                            pricing=None):
    """Compare all three compression patterns side-by-side: direct, selective removal,
    and model-as-compressor.

    Displays a full-width styled table comparing tokens, cost, and time for:
      1. Direct — full document to expensive model
      2. Selective removal — strip filler, then send to expensive model
      3. Model-as-compressor — compress with cheap model, then analyze with expensive model

    Args:
        bedrock_client: boto3 bedrock-runtime client.
        document: the full text to analyze.
        model_id: expensive model for analysis.
        compressor_id: cheap model for compression step.
        analysis_question: prompt prefix for analysis. Defaults to a generic one.
        pricing: optional dict with "compressor" and "analyzer" sub-dicts.

    Returns:
        dict with results for each method.
    """
    import time
    from IPython.display import display

    if pricing is None:
        pricing = {
            "compressor": {"input": 0.035, "output": 0.14},
            "analyzer": {"input": 3.00, "output": 15.00},
        }
    if analysis_question is None:
        analysis_question = "Analyze this support case and recommend resolution:\n\n"

    # ─── Method 1: Direct ────────────────────────────────────────────────
    start = time.time()
    direct_resp = bedrock_client.converse(
        modelId=model_id,
        messages=[{"role": "user", "content": [{"text": f"{analysis_question}{document}"}]}],
        inferenceConfig={"maxTokens": 300}
    )
    direct_time = time.time() - start
    direct_usage = direct_resp["usage"]
    direct_cost = (
        direct_usage["inputTokens"] * pricing["analyzer"]["input"] +
        direct_usage["outputTokens"] * pricing["analyzer"]["output"]
    ) / 1e6

    # ─── Method 2: Selective removal ─────────────────────────────────────
    removal_result = selective_removal(document)
    cleaned_text = removal_result["cleaned"]

    start = time.time()
    selective_resp = bedrock_client.converse(
        modelId=model_id,
        messages=[{"role": "user", "content": [{"text": f"{analysis_question}{cleaned_text}"}]}],
        inferenceConfig={"maxTokens": 300}
    )
    selective_time = time.time() - start
    selective_usage = selective_resp["usage"]
    selective_cost = (
        selective_usage["inputTokens"] * pricing["analyzer"]["input"] +
        selective_usage["outputTokens"] * pricing["analyzer"]["output"]
    ) / 1e6

    # ─── Method 3: Model-as-compressor ───────────────────────────────────
    compress_instruction = ("Compress the following to its essential facts. "
                           "Remove redundancy, pleasantries, repetition. "
                           "Preserve: dates, amounts, order numbers, key actions, status. "
                           "Output only the compressed version.")

    start = time.time()
    compress_resp = bedrock_client.converse(
        modelId=compressor_id,
        messages=[{"role": "user", "content": [{"text": f"{compress_instruction}\n\n{document}"}]}],
        inferenceConfig={"maxTokens": 500}
    )
    compressed_text = compress_resp["output"]["message"]["content"][0]["text"]
    compress_usage = compress_resp["usage"]

    analysis_resp = bedrock_client.converse(
        modelId=model_id,
        messages=[{"role": "user", "content": [{"text": f"{analysis_question}{compressed_text}"}]}],
        inferenceConfig={"maxTokens": 300}
    )
    compressor_time = time.time() - start
    analysis_usage = analysis_resp["usage"]

    compressor_cost = (
        compress_usage["inputTokens"] * pricing["compressor"]["input"] +
        compress_usage["outputTokens"] * pricing["compressor"]["output"] +
        analysis_usage["inputTokens"] * pricing["analyzer"]["input"] +
        analysis_usage["outputTokens"] * pricing["analyzer"]["output"]
    ) / 1e6

    # ─── Full-width table styling ────────────────────────────────────────
    _table_styles = [
        {"selector": "", "props": [("width", "100%"), ("border-collapse", "collapse")]},
        {"selector": "caption", "props": [("font-size", "14px"), ("font-weight", "bold"),
                                          ("color", "#43004d"), ("text-align", "left"),
                                          ("padding-bottom", "8px")]},
        {"selector": "th", "props": [("background-color", "#43004d"), ("color", "white"),
                                     ("text-align", "center"), ("padding", "8px 12px"),
                                     ("text-transform", "uppercase"), ("font-size", "12px")]},
        {"selector": "td", "props": [("padding", "6px 12px"), ("text-align", "center"),
                                     ("border-bottom", f"1px solid {PLUM_PALE}"),
                                     ("background-color", "white")]},
    ]

    # ─── Table 1: Side-by-side comparison ────────────────────────────────
    min_cost = min(direct_cost, selective_cost, compressor_cost)
    comp_df = pd.DataFrame([
        {
            "Method": "📄 Direct",
            "Input Tokens": direct_usage["inputTokens"],
            "Output Tokens": direct_usage["outputTokens"],
            "Latency (s)": round(direct_time, 2),
            "Cost ($)": direct_cost,
            "vs Cheapest": direct_cost / min_cost if min_cost else 0,
            "Savings": "—",
        },
        {
            "Method": "✂️ Selective Removal",
            "Input Tokens": selective_usage["inputTokens"],
            "Output Tokens": selective_usage["outputTokens"],
            "Latency (s)": round(selective_time, 2),
            "Cost ($)": selective_cost,
            "vs Cheapest": selective_cost / min_cost if min_cost else 0,
            "Savings": f"{(1 - selective_cost / direct_cost) * 100:.1f}%",
        },
        {
            "Method": "💻 Model-as-Compressor",
            "Input Tokens": analysis_usage["inputTokens"],
            "Output Tokens": analysis_usage["outputTokens"],
            "Latency (s)": round(compressor_time, 2),
            "Cost ($)": compressor_cost,
            "vs Cheapest": compressor_cost / min_cost if min_cost else 0,
            "Savings": f"{(1 - compressor_cost / direct_cost) * 100:.1f}%",
        },
    ])
    styler1 = (comp_df.style.hide(axis="index")
               .set_caption("All Three Compression Patterns Compared")
               .set_table_styles(_table_styles)
               .set_properties(subset=["Method"], **{"text-align": "left", "font-weight": "bold"})
               .format({
                   "Cost ($)": "${:.6f}",
                   "Input Tokens": "{:,}",
                   "Output Tokens": "{:,}",
                   "vs Cheapest": "{:.1f}×",
               }))
    display(styler1)

    return {
        "direct": {"time": direct_time, "cost": direct_cost, "usage": direct_usage},
        "selective": {"time": selective_time, "cost": selective_cost, "usage": selective_usage,
                      "removal": removal_result},
        "compressor": {"time": compressor_time, "cost": compressor_cost,
                       "compress_usage": compress_usage, "analysis_usage": analysis_usage},
    }


def evaluate_compression_prompt(bedrock_client, tickets, compression_prompt,
                                compressor_id="us.amazon.nova-micro-v1:0",
                                classifier_id="us.amazon.nova-micro-v1:0",
                                n=50):
    """Evaluate a student's compression prompt by checking classification accuracy.

    Pipeline per ticket:
      1. Compress the ticket using the student's compression_prompt
      2. Classify the compressed ticket into queue + priority
      3. Compare classification against ground truth

    Displays styled tables with per-ticket results and overall accuracy.

    Args:
        bedrock_client: boto3 bedrock-runtime client.
        tickets: list of ticket dicts with 'subject', 'body', 'queue', 'priority'.
        compression_prompt: the student's compression system prompt (string).
            This is prepended to each ticket before sending to the compressor model.
        compressor_id: model to use for compression.
        classifier_id: model to use for classification.
        n: number of tickets to evaluate (default 50).

    Returns:
        dict with "accuracy_queue", "accuracy_priority", "results_df".
    """
    import time
    from IPython.display import display, HTML

    VALID_QUEUES = [
        "Billing and Payments", "Customer Service", "General Inquiry",
        "IT Support", "Product Support", "Returns and Exchanges",
        "Sales and Pre-Sales", "Service Outages and Maintenance", "Technical Support"
    ]
    VALID_PRIORITIES = ["high", "medium", "low"]

    classify_instruction = (
        f"Classify this support ticket.\n"
        f"Queue (choose exactly one): {', '.join(VALID_QUEUES)}\n"
        f"Priority (choose exactly one): {', '.join(VALID_PRIORITIES)}\n\n"
        f"Respond in exactly this format:\n"
        f"Queue: <queue>\nPriority: <priority>"
    )

    eval_tickets = tickets[:n]
    results = []
    total_compress_tokens = 0
    total_classify_tokens = 0

    start_all = time.time()
    for i, t in enumerate(eval_tickets):
        ticket_text = f"Subject: {t['subject']}\n{t['body']}"

        # Step 1: Compress using student's prompt
        try:
            compress_resp = bedrock_client.converse(
                modelId=compressor_id,
                messages=[{"role": "user", "content": [
                    {"text": f"{compression_prompt}\n\n{ticket_text}"}
                ]}],
                inferenceConfig={"maxTokens": 300}
            )
            compressed = compress_resp["output"]["message"]["content"][0]["text"]
            total_compress_tokens += compress_resp["usage"]["inputTokens"] + compress_resp["usage"]["outputTokens"]
        except Exception as e:
            results.append({
                "Ticket #": i + 1,
                "True Queue": t["queue"],
                "Predicted Queue": f"ERROR: {str(e)[:30]}",
                "Queue ✓": "❌",
                "True Priority": t["priority"],
                "Predicted Priority": "—",
                "Priority ✓": "❌",
            })
            continue

        # Step 2: Classify compressed text
        try:
            classify_resp = bedrock_client.converse(
                modelId=classifier_id,
                messages=[{"role": "user", "content": [
                    {"text": f"{classify_instruction}\n\nTicket:\n{compressed}"}
                ]}],
                inferenceConfig={"maxTokens": 50}
            )
            classification = classify_resp["output"]["message"]["content"][0]["text"]
            total_classify_tokens += classify_resp["usage"]["inputTokens"] + classify_resp["usage"]["outputTokens"]
        except Exception as e:
            results.append({
                "Ticket #": i + 1,
                "True Queue": t["queue"],
                "Predicted Queue": f"ERROR: {str(e)[:30]}",
                "Queue ✓": "❌",
                "True Priority": t["priority"],
                "Predicted Priority": "—",
                "Priority ✓": "❌",
            })
            continue

        # Parse classification output
        pred_queue = "Unknown"
        pred_priority = "unknown"
        for line in classification.strip().split("\n"):
            line_lower = line.lower().strip()
            if line_lower.startswith("queue:"):
                pred_queue = line.split(":", 1)[1].strip()
            elif line_lower.startswith("priority:"):
                pred_priority = line.split(":", 1)[1].strip().lower()

        queue_correct = pred_queue.lower() == t["queue"].lower()
        priority_correct = pred_priority == t["priority"].lower()

        results.append({
            "Ticket #": i + 1,
            "True Queue": t["queue"],
            "Predicted Queue": pred_queue,
            "Queue ✓": "✅" if queue_correct else "❌",
            "True Priority": t["priority"],
            "Predicted Priority": pred_priority,
            "Priority ✓": "✅" if priority_correct else "❌",
        })

    total_time = time.time() - start_all

    # Calculate accuracy
    queue_correct = sum(1 for r in results if r["Queue ✓"] == "✅")
    priority_correct = sum(1 for r in results if r["Priority ✓"] == "✅")
    n_evaluated = len(results)
    queue_accuracy = queue_correct / n_evaluated * 100 if n_evaluated else 0
    priority_accuracy = priority_correct / n_evaluated * 100 if n_evaluated else 0

    # ─── Full-width table styling ────────────────────────────────────────
    _table_styles = [
        {"selector": "", "props": [("width", "100%"), ("min-width", "100%"),
                                   ("table-layout", "fixed"), ("border-collapse", "collapse")]},
        {"selector": "caption", "props": [("font-size", "14px"), ("font-weight", "bold"),
                                          ("color", "#43004d"), ("text-align", "left"),
                                          ("padding-bottom", "8px")]},
        {"selector": "th", "props": [("background-color", "#43004d"), ("color", "white"),
                                     ("text-align", "center"), ("padding", "8px 12px"),
                                     ("text-transform", "uppercase"), ("font-size", "12px")]},
        {"selector": "td", "props": [("padding", "6px 12px"),
                                     ("border-bottom", f"1px solid {PLUM_PALE}"),
                                     ("background-color", "white")]},
        {"selector": "th:first-child, td:first-child", "props": [("width", "25%"), ("text-align", "left"), ("font-weight", "bold")]},
        {"selector": "th:nth-child(2), td:nth-child(2)", "props": [("width", "20%"), ("text-align", "center")]},
        {"selector": "th:nth-child(3), td:nth-child(3)", "props": [("width", "55%"), ("text-align", "left")]},
    ]

    # ─── Table 1: Summary ────────────────────────────────────────────────
    summary_df = pd.DataFrame([
        {
            "Metric": "🎯 Queue Accuracy",
            "Value": f"{queue_accuracy:.1f}%",
            "Detail": f"{queue_correct}/{n_evaluated} tickets classified correctly",
        },
        {
            "Metric": "🎯 Priority Accuracy",
            "Value": f"{priority_accuracy:.1f}%",
            "Detail": f"{priority_correct}/{n_evaluated} priorities classified correctly",
        },
        {
            "Metric": "⏱️ Total Time",
            "Value": f"{total_time:.1f}s",
            "Detail": f"{total_time/n_evaluated:.2f}s per ticket (compress + classify)",
        },
        {
            "Metric": "🔤 Tokens Used",
            "Value": f"{total_compress_tokens + total_classify_tokens:,}",
            "Detail": f"Compress: {total_compress_tokens:,} + Classify: {total_classify_tokens:,}",
        },
    ])
    styler1 = (summary_df.style.hide(axis="index")
               .set_caption("① Compression Prompt Evaluation Summary")
               .set_table_styles(_table_styles))
    display(styler1)
    display(HTML("<div style='margin-top: 40px;'></div>"))

    # ─── Table 2: Per-ticket results (show first 15 + any errors) ────────
    results_df = pd.DataFrame(results)
    errors = results_df[results_df["Queue ✓"] == "❌"]
    show_df = results_df.head(15) if len(errors) > 15 else pd.concat([
        results_df.head(10),
        errors.head(5)
    ]).drop_duplicates().sort_values("Ticket #").reset_index(drop=True)

    _table2_styles = [
        {"selector": "", "props": [("width", "100%"), ("min-width", "100%"),
                                   ("table-layout", "auto"), ("border-collapse", "collapse"),
                                   ("font-size", "12px"), ("word-wrap", "break-word"),
                                   ("margin-top", "20px")]},
        {"selector": "caption", "props": [("font-size", "14px"), ("font-weight", "bold"),
                                          ("color", "#43004d"), ("text-align", "left"),
                                          ("padding-bottom", "8px")]},
        {"selector": "th", "props": [("background-color", "#43004d"), ("color", "white"),
                                     ("text-align", "center"), ("padding", "6px 8px"),
                                     ("white-space", "nowrap"), ("text-transform", "uppercase"),
                                     ("font-size", "11px")]},
        {"selector": "td", "props": [("padding", "4px 8px"),
                                     ("border-bottom", f"1px solid {PLUM_PALE}"),
                                     ("background-color", "white"),
                                     ("overflow", "hidden"), ("text-overflow", "ellipsis"),
                                     ("max-width", "180px")]},
        {"selector": "th:first-child, td:first-child", "props": [("text-align", "center"), ("width", "60px")]},
        {"selector": "th:nth-child(4), td:nth-child(4), th:nth-child(7), td:nth-child(7)",
         "props": [("width", "40px"), ("text-align", "center")]},
    ]

    styler2 = (show_df.style.hide(axis="index")
               .set_caption(f"② Per-Ticket Results (showing {len(show_df)} of {n_evaluated})")
               .set_table_styles(_table2_styles))
    display(styler2)

    # ─── Verdict ─────────────────────────────────────────────────────────
    if queue_accuracy >= 60:
        print(f"\n✅ Great compression prompt! {queue_accuracy:.0f}% queue accuracy — "
              f"your compressed text preserves enough signal for correct classification.")
    elif queue_accuracy >= 30:
        print(f"\n⚠️ Decent but room to improve. {queue_accuracy:.0f}% queue accuracy — "
              f"try preserving more category-specific keywords (billing terms, technical jargon, etc.).")
    else:
        print(f"\n❌ Compression is too aggressive. {queue_accuracy:.0f}% queue accuracy — "
              f"the compressed text is losing the signals the classifier needs. "
              f"Try instructing the compressor to preserve the topic and key terms.")

    return {
        "accuracy_queue": queue_accuracy,
        "accuracy_priority": priority_accuracy,
        "results_df": results_df,
        "time": total_time,
    }


# ---------------------------------------------------------------------------
# Lab 6 — Smart dispatch
# ---------------------------------------------------------------------------

def run_routing_experiment(tickets, bedrock_runtime, pricing, n=100):
    """Route tickets by complexity and return cost comparison metrics.

    Uses the ground-truth priority label as a complexity proxy:
    high-priority tickets go to Sonnet, the rest to Nova Micro.

    Args:
        tickets: list of ticket dicts with 'subject', 'body', 'priority' keys.
        bedrock_runtime: boto3 bedrock-runtime client.
        pricing: dict mapping model IDs to {"input": rate, "output": rate}.
        n: number of tickets to process (default 100).

    Returns:
        tuple of (baseline_cost, routed_cost, savings_pct)
    """
    COMPLEX_MODEL = "us.anthropic.claude-sonnet-4-5-20250929-v1:0"
    SIMPLE_MODEL = "us.amazon.nova-micro-v1:0"

    routing_tickets = tickets[:n]
    routed_cost = 0
    baseline_cost = 0

    for t in routing_tickets:
        text = f"{t['subject']}\n{t['body']}"

        # Decide if this ticket needs the powerful model or the cheap one
        if t["priority"] == "high":
            model = COMPLEX_MODEL
        else:
            model = SIMPLE_MODEL

        response = bedrock_runtime.converse(
            modelId=model,
            messages=[{"role": "user", "content": [{"text": f"Analyze this support ticket: {text}"}]}],
            inferenceConfig={"maxTokens": 200}
        )

        usage = response["usage"]
        p = pricing[model]
        routed_cost += (usage["inputTokens"] * p["input"] + usage["outputTokens"] * p["output"]) / 1e6

        # Baseline: everything to Sonnet
        p_sonnet = pricing[COMPLEX_MODEL]
        baseline_cost += (usage["inputTokens"] * p_sonnet["input"] + usage["outputTokens"] * p_sonnet["output"]) / 1e6

    savings_pct = (1 - routed_cost / baseline_cost) * 100
    return baseline_cost, routed_cost, savings_pct


def track_routing_costs(tickets, bedrock_runtime, pricing, n=100):
    """Route tickets by complexity and return cost metrics plus model distribution.

    Uses the ground-truth priority label as a complexity proxy:
    high-priority tickets go to Sonnet, the rest to Nova Micro.

    Args:
        tickets: list of ticket dicts with 'subject', 'body', 'priority' keys.
        bedrock_runtime: boto3 bedrock-runtime client.
        pricing: dict mapping model IDs to {"input": rate, "output": rate, "name": str}.
        n: number of tickets to process (default 100).

    Returns:
        tuple of (baseline_cost, routed_cost, savings_pct, distribution)
    """
    COMPLEX_MODEL = "us.anthropic.claude-sonnet-4-5-20250929-v1:0"
    SIMPLE_MODEL = "us.amazon.nova-micro-v1:0"

    routing_tickets = tickets[:n]
    baseline_cost = 0
    routed_cost = 0
    distribution = []

    for t in routing_tickets:
        text = f"{t['subject']}\n{t['body']}"

        if t["priority"] == "high":
            model = COMPLEX_MODEL
        else:
            model = SIMPLE_MODEL

        response = bedrock_runtime.converse(
            modelId=model,
            messages=[{"role": "user", "content": [{"text": f"Analyze this support ticket: {text}"}]}],
            inferenceConfig={"maxTokens": 200}
        )

        usage = response["usage"]
        p = pricing[model]
        routed_cost += (usage["inputTokens"] * p["input"] + usage["outputTokens"] * p["output"]) / 1e6

        p_baseline = pricing[COMPLEX_MODEL]
        baseline_cost += (usage["inputTokens"] * p_baseline["input"] + usage["outputTokens"] * p_baseline["output"]) / 1e6

        distribution.append({"Routed to": p["name"]})

    savings_pct = (1 - routed_cost / baseline_cost) * 100 if baseline_cost > 0 else 0

    return baseline_cost, routed_cost, savings_pct, distribution


def plot_routing_savings(baseline_cost, routed_cost, savings_pct):
    """Bar chart: all-Sonnet baseline vs manual routing cost."""
    fig = px.bar(
        pd.DataFrame([
            {"Approach": "Baseline (all Sonnet)", "Cost ($)": baseline_cost},
            {"Approach": "Manual routing", "Cost ($)": routed_cost},
        ]),
        x="Approach", y="Cost ($)", color="Approach", text="Cost ($)",
        title=f"Manual Routing Cost ({savings_pct:.0f}% savings)",
        color_discrete_sequence=[PLUM, PLUM_LIGHT],
    )
    fig.update_traces(texttemplate="$%{y:.5f}", textposition="inside", textfont_color="white")
    fig.update_layout(showlegend=False, height=400)
    fig.show()


def plot_router_distribution(rows):
    """Donut chart of how a managed prompt router distributed requests.

    Args:
        rows: list of dicts each containing a "Routed to" key (model name).
    """
    router_df = pd.DataFrame(rows)
    dist = router_df["Routed to"].value_counts().reset_index()
    dist.columns = ["Model", "Requests"]
    fig = px.pie(dist, names="Model", values="Requests", hole=0.45,
                 title="Bedrock Prompt Router: Model Selection Distribution",
                 color_discrete_sequence=[CYAN, PURPLE])
    fig.update_layout(height=420)
    fig.show()
    print("💡 Bedrock chose the model per-request based on predicted response quality.")


def plot_cascading_savings(total_baseline_cost, total_cascade_cost, savings,
                           escalation_count, n_docs):
    """Bar chart: all-Sonnet baseline vs cascading cost."""
    fig = px.bar(
        pd.DataFrame([
            {"Approach": "Baseline (all Sonnet)", "Cost ($)": total_baseline_cost},
            {"Approach": "Cascading", "Cost ($)": total_cascade_cost},
        ]),
        x="Approach", y="Cost ($)", color="Approach", text="Cost ($)",
        title=f"Cascading Cost ({savings:.0f}% savings, {escalation_count}/{n_docs} escalated)",
        color_discrete_sequence=[PINK, CYAN],
    )
    fig.update_traces(texttemplate="$%{y:.5f}", textposition="outside")
    fig.update_layout(showlegend=False, height=400)
    fig.show()


def print_accuracy_cost_tradeoff(model_stats):
    """Print a summary comparing accuracy vs cost across models.

    Args:
        model_stats: dict of {model_name: {"accuracy": float, "cost": float}}.
            Expects at least "Nova Micro" and "Claude Sonnet" keys.
    """
    print(f"\n{'='*60}")
    print(f"\U0001f4ca Accuracy vs Cost Tradeoff (on real labeled data)")
    print(f"{'='*60}")
    min_cost = min(s["cost"] for s in model_stats.values()) if model_stats else 0
    comparison = pd.DataFrame([
        {"Model": name, "Accuracy": f"{s['accuracy']:.1f}%", "Cost": f"${s['cost']:.6f}",
         "vs Cheapest": f"{s['cost'] / min_cost:.1f}×" if min_cost else "—"}
        for name, s in model_stats.items()
    ])
    print(tabulate(comparison, headers="keys", tablefmt="grid", showindex=False))

    micro = model_stats["Nova Micro"]
    sonnet = model_stats["Claude Sonnet"]
    acc_gap = sonnet["accuracy"] - micro["accuracy"]
    cost_ratio = sonnet["cost"] / micro["cost"] if micro["cost"] > 0 else 0
    print(f"\n\U0001f4a1 Nova Micro costs {cost_ratio:.0f}x less than Sonnet.")

def run_parallel_decomposition(bedrock_runtime, run_subtask, sub_tasks, document,
                               sonnet_id="us.anthropic.claude-sonnet-4-5-20250929-v1:0"):
    """Run parallel sub-tasks on Nova Micro and compare against a single Sonnet call.

    Args:
        bedrock_runtime: boto3 bedrock-runtime client.
        run_subtask: function(name, instruction, document) -> dict with task, result, time_s, cost.
        sub_tasks: dict of {task_name: instruction_string}.
        document: the document text to analyze.
        sonnet_id: model ID for the single-call comparison.

    Returns:
        dict with parallel_results, parallel_time, parallel_cost, sonnet_time, sonnet_cost.
    """
    import concurrent.futures

    # Run in parallel
    print("Running 4 sub-tasks in parallel on Nova Micro...\n")
    parallel_start = time.time()

    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
        futures = {
            executor.submit(run_subtask, name, instr, document): name
            for name, instr in sub_tasks.items()
        }
        parallel_results = {}
        for future in concurrent.futures.as_completed(futures):
            result = future.result()
            parallel_results[result["task"]] = result

    parallel_total_time = time.time() - parallel_start
    parallel_total_cost = sum(r["cost"] for r in parallel_results.values())
    sequential_total_time = sum(r["time_s"] for r in parallel_results.values())

    # Compare with single Sonnet call
    sonnet_start = time.time()
    sonnet_response = bedrock_runtime.converse(
        modelId=sonnet_id,
        messages=[{"role": "user", "content": [{"text": f"Provide: summary, entities, sentiment, and action items for:\n\n{document}"}]}],
        inferenceConfig={"maxTokens": 500}
    )
    sonnet_time = time.time() - sonnet_start
    su = sonnet_response["usage"]
    sonnet_cost = (su["inputTokens"] * 3.00 + su["outputTokens"] * 15.00) / 1e6

    print(f"{'='*60}")
    print(f"\U0001f4ca Parallel Decomposition Results")
    print(f"{'='*60}")
    print(f"{'Method':<25} {'Time (s)':<12} {'Cost ($)':<12}")
    print(f"{'-'*49}")
    print(f"{'Parallel (4x Micro)':<25} {parallel_total_time:<12.2f} ${parallel_total_cost:.6f}")
    print(f"{'Sequential (4x Micro)':<25} {sequential_total_time:<12.2f} ${parallel_total_cost:.6f}")
    print(f"{'Single Sonnet call':<25} {sonnet_time:<12.2f} ${sonnet_cost:.6f}")
    print(f"\n\U0001f4b0 Cost savings vs Sonnet: {(1-parallel_total_cost/sonnet_cost)*100:.1f}%")
    print(f"\u23f1\ufe0f  Speed improvement (parallel vs sequential): {sequential_total_time/parallel_total_time:.1f}x")

    # Show results
    print(f"\n{'='*60}")
    print("Sub-task results:")
    for name, r in parallel_results.items():
        print(f"\n\U0001f4cc {name}: {r['result'][:150]}")

    return {
        "parallel_results": parallel_results,
        "parallel_time": parallel_total_time,
        "parallel_cost": parallel_total_cost,
        "sequential_time": sequential_total_time,
        "sonnet_time": sonnet_time,
        "sonnet_cost": sonnet_cost,
    }


def calculate_parallel_costs(results, pricing, bedrock_runtime, document):
    """Calculate cost and timing stats from parallel subtask results, including a Sonnet baseline.

    Args:
        results: dict of {task_name: result_dict} where each result_dict has
                 'time_s', 'model', and 'usage' keys (from run_subtask).
        pricing: dict mapping model IDs to {"input": rate, "output": rate}.
        bedrock_runtime: boto3 bedrock-runtime client.
        document: the document text used for subtasks (sent to Sonnet as baseline).

    Returns:
        tuple of (parallel_total_time, sequential_total_time, sonnet_time,
                  parallel_total_cost, sonnet_cost)
    """
    parallel_total_time = max(r["time_s"] for r in results.values())
    sequential_total_time = sum(r["time_s"] for r in results.values())
    parallel_total_cost = 0

    for r in results.values():
        p = pricing[r["model"]]
        u = r["usage"]
        parallel_total_cost += (u["inputTokens"] * p["input"] + u["outputTokens"] * p["output"]) / 1e6

    # Baseline: run the full task on Sonnet as a single call
    sonnet_model = "us.anthropic.claude-sonnet-4-5-20250929-v1:0"
    start = time.time()
    sonnet_response = bedrock_runtime.converse(
        modelId=sonnet_model,
        messages=[{"role": "user", "content": [{"text":
            f"Summarize, extract entities, rate sentiment, and list action items:\n\n{document}"}]}],
        inferenceConfig={"maxTokens": 500}
    )
    sonnet_time = time.time() - start
    su = sonnet_response["usage"]
    p_sonnet = pricing[sonnet_model]
    sonnet_cost = (su["inputTokens"] * p_sonnet["input"] + su["outputTokens"] * p_sonnet["output"]) / 1e6

    return parallel_total_time, sequential_total_time, sonnet_time, parallel_total_cost, sonnet_cost


def plot_parallel_performance(parallel_total_time, sequential_total_time, sonnet_time,
                              parallel_total_cost, sonnet_cost):
    """Bar charts of latency and cost: parallel vs sequential vs single Sonnet."""
    from IPython.display import display

    perf_df = pd.DataFrame([
        {"Method": "Parallel (4x Micro)", "Time (s)": parallel_total_time, "Cost ($)": parallel_total_cost},
        {"Method": "Sequential (4x Micro)", "Time (s)": sequential_total_time, "Cost ($)": parallel_total_cost},
        {"Method": "Single Sonnet call", "Time (s)": sonnet_time, "Cost ($)": sonnet_cost},
    ])

    # Add ratio column
    min_cost = perf_df["Cost ($)"].min()
    perf_df["vs Cheapest"] = perf_df["Cost ($)"].apply(lambda c: f"{c / min_cost:.1f}×" if min_cost else "—")

    # Uppercase all column headers
    perf_df = perf_df.rename(columns={c: c.upper() for c in perf_df.columns})

    styler = (perf_df.style.hide(axis="index")
              .format({"TIME (S)": "{:.2f}", "COST ($)": "${:.6f}"})
              .set_properties(**{"text-align": "center"})
              .set_properties(subset=["METHOD"], **{"text-align": "left", "font-weight": "bold"})
              .set_table_styles([
                  {"selector": "", "props": [("width", "100%")]},
                  {"selector": "th", "props": [
                      ("background-color", "#43004d"), ("color", "white"),
                      ("padding", "8px 12px"), ("text-align", "center"), ("font-size", "13px")
                  ]},
                  {"selector": "td", "props": [("padding", "8px 12px"), ("font-size", "13px")]},
                  {"selector": "tr:hover", "props": [("background-color", "#f0ebf1")]},
              ]))
    display(styler)

    fig = px.bar(perf_df, x="METHOD", y="TIME (S)", color="METHOD", text="TIME (S)",
                 title="Latency: Parallel vs Sequential vs Single Sonnet",
                 color_discrete_sequence=SEQ3)
    fig.update_traces(texttemplate="%{y:.2f}s", textposition="inside", textfont_color="white")
    fig.update_layout(showlegend=False, height=400)
    fig.show()

    fig2 = px.bar(perf_df, x="METHOD", y="COST ($)", color="METHOD", text="COST ($)",
                  title="Cost: Parallel/Sequential Micro vs Single Sonnet",
                  color_discrete_sequence=SEQ3)
    fig2.update_traces(texttemplate="$%{y:.6f}", textposition="inside", textfont_color="white")
    fig2.update_layout(showlegend=False, height=400)
    fig2.show()


def plot_accuracy_vs_cost(model_stats):
    """Scatter of accuracy vs cost (log x) for each model.

    Args:
        model_stats: dict of {model_name: {"accuracy": float, "cost": float}}.
    """
    acc_df = pd.DataFrame([
        {"Model": name, "Accuracy (%)": s["accuracy"], "Cost ($)": s["cost"]}
        for name, s in model_stats.items()
    ])
    fig = px.scatter(acc_df, x="Cost ($)", y="Accuracy (%)", color="Model", text="Model",
                     size=[20] * len(acc_df),
                     title="Accuracy vs Cost: Nova Micro vs Claude Sonnet",
                     color_discrete_sequence=[CYAN, PINK])
    fig.update_traces(textposition="top center")
    fig.update_xaxes(type="log")
    fig.update_layout(showlegend=False, height=430)
    fig.show()
    print("💡 Up and to the LEFT is ideal: high accuracy, low cost.")


# ---------------------------------------------------------------------------
# Lab 7 — Capstone
# ---------------------------------------------------------------------------
def plot_cumulative_savings(results):
    """Bar chart of monthly cost as optimization layers stack.

    Args:
        results: list of dicts with keys "Optimization" and "Monthly Cost"
                 (formatted like "$1234.56").
    """
    cum_df = pd.DataFrame(results)
    cum_df["Monthly Cost ($)"] = [float(r["Monthly Cost"].replace("$", "")) for r in results]
    fig = px.bar(cum_df, x="Optimization", y="Monthly Cost ($)", text="Monthly Cost ($)",
                 title="Monthly Cost as Optimization Layers Stack",
                 color="Monthly Cost ($)",
                 color_continuous_scale=[CYAN, PURPLE, PINK][::-1])
    fig.update_traces(texttemplate="$%{y:.0f}", textposition="outside")
    fig.update_layout(height=450, coloraxis_showscale=False)
    fig.show()
    print("💡 Each layer compounds on the last. Caching, routing, and compression together")
    print("   drive the cost down multiplicatively — the essence of the stacking strategy.")


def plot_model_mix(design, monthly_cost):
    """Donut of the model mix a capstone design assigns.

    Args:
        design: dict with keys pct_nova_micro, pct_nova_lite, pct_claude_sonnet,
                budget_monthly.
        monthly_cost: float, the design's computed monthly cost.
    """
    mix_df = pd.DataFrame([
        {"Model": "Nova Micro", "Share": design["pct_nova_micro"]},
        {"Model": "Nova Lite", "Share": design["pct_nova_lite"]},
        {"Model": "Claude Sonnet", "Share": design["pct_claude_sonnet"]},
    ])
    fig = px.pie(mix_df, names="Model", values="Share", hole=0.45,
                 title=f"Design Model Mix (monthly cost: ${monthly_cost:.2f} vs ${design['budget_monthly']:.0f} budget)",
                 color_discrete_sequence=SEQ3)
    fig.update_traces(textinfo="label+percent")
    fig.update_layout(height=430)
    fig.show()
    print("💡 Sending the bulk of traffic to the cheapest capable model is what keeps")
    print("   the design under budget — the skew principle made literal.")


def plot_quality_vs_cost(sonnet_acc, cascade_acc, sonnet_cost, cascade_cost):
    """Dual-axis grouped bar: accuracy and cost for all-Sonnet vs cascading."""
    qc_df = pd.DataFrame([
        {"Architecture": "All-Sonnet", "Accuracy (%)": sonnet_acc, "Cost ($)": sonnet_cost},
        {"Architecture": "Cascading", "Accuracy (%)": cascade_acc, "Cost ($)": cascade_cost},
    ])
    fig = go.Figure()
    fig.add_trace(go.Bar(x=qc_df["Architecture"], y=qc_df["Accuracy (%)"],
                         name="Accuracy (%)", marker_color=PURPLE,
                         text=[f"{v:.0f}%" for v in qc_df["Accuracy (%)"]], textposition="outside"))
    fig.add_trace(go.Bar(x=qc_df["Architecture"], y=qc_df["Cost ($)"],
                         name="Cost ($)", marker_color=PINK, yaxis="y2",
                         text=[f"${v:.5f}" for v in qc_df["Cost ($)"]], textposition="outside"))
    fig.update_layout(
        title="Quality vs Cost: Cascading vs All-Sonnet Baseline",
        yaxis=dict(title="Accuracy (%)"),
        yaxis2=dict(title="Cost ($)", overlaying="y", side="right"),
        barmode="group", height=450, legend=dict(x=0.02, y=0.98),
    )
    fig.show()
    print("💡 The goal: match accuracy (purple) while slashing cost (red). Cascading holds")
    print("   quality within the 5% bar at a fraction of the all-Sonnet cost.")


# ---------------------------------------------------------------------------
# Lab 1 — Live pricing (AWS Price List API)
# ---------------------------------------------------------------------------
def plot_live_pricing(price_df):
    """Grouped bar of live input vs output price per 1M tokens by model.

    Args:
        price_df: DataFrame with columns Model, Token Type ("input"/"output"),
                  and "Price ($/1M tokens)".
    """
    if price_df is None or len(price_df) == 0:
        print("No live pricing data to plot.")
        return
    fig = px.bar(price_df, x="Model", y="Price ($/1M tokens)", color="Token Type",
                 barmode="group", text="Price ($/1M tokens)",
                 title="Live Bedrock On-Demand Pricing (per 1M tokens)",
                 color_discrete_map={"input": GOLD, "output": PLUM_LIGHT})
    fig.update_traces(texttemplate="$%{y:.2f}", textposition="outside")
    fig.update_layout(height=430, margin=dict(t=50))
    fig.show()


def print_prompt_comparison(verbose_result, concise_result):
    """Print a formatted comparison of verbose vs concise prompt costs.

    Args:
        verbose_result: dict from invoke_and_measure for the verbose prompt.
        concise_result: dict from invoke_and_measure for the concise prompt.
    """
    print(f"\n{'='*60}")
    print(f"\U0001f4b0 Prompt Cost Comparison (same task, same model)")
    print(f"{'='*60}")
    print(f"Verbose - Input: {verbose_result['input_tokens']} tokens, "
          f"Output: {verbose_result['output_tokens']} tokens, "
          f"Cost: ${verbose_result['cost_usd']:.6f}")
    print(f"Lean    - Input: {concise_result['input_tokens']} tokens, "
          f"Output: {concise_result['output_tokens']} tokens, "
          f"Cost: ${concise_result['cost_usd']:.6f}")
    savings = (1 - concise_result['cost_usd'] / verbose_result['cost_usd']) * 100 if verbose_result['cost_usd'] else 0
    print(f"💰 Cost savings: {savings:.0f}% per request")


def compare_prompt_costs(invoke_fn, model_id, labeled_prompts):
    """Run each labeled prompt through the same model and show a styled cost table.

    Args:
        invoke_fn: a function like invoke_and_measure(model_id, prompt) that returns
                   a dict with input_tokens, output_tokens, latency_s, cost_usd.
        model_id: the model to use for every prompt.
        labeled_prompts: dict of {label: prompt_text}. The first entry is treated as
                         the baseline for the savings calculation.

    Returns:
        The comparison DataFrame.
    """
    rows, costs = [], []
    for label, prompt in labeled_prompts.items():
        r = invoke_fn(model_id, prompt)
        costs.append(r["cost_usd"])
        rows.append({
            "PROMPT": label,
            "INPUT TOKENS": r["input_tokens"],
            "OUTPUT TOKENS": r["output_tokens"],
            "LATENCY (S)": r["latency_s"],
            "COST ($)": r["cost_usd"],
        })
    df = pd.DataFrame(rows)

    # Add ratio column comparing each row to the cheapest
    min_cost = df["COST ($)"].min()
    df["VS CHEAPEST"] = df["COST ($)"].apply(lambda c: f"{c / min_cost:.1f}×" if min_cost else "—")

    styled_table(df, caption="Prompt cost comparison (same task, same model)")

    if len(costs) >= 2 and costs[0]:
        savings = (1 - costs[-1] / costs[0]) * 100
        print(f"💰 Cost savings: {savings:.0f}% per request")
    return df


# ---------------------------------------------------------------------------
# Lab 1 — Live pricing fetch (AWS Price List API)
# ---------------------------------------------------------------------------
# Bedrock region -> Price List "location" string
_REGION_LOCATION = {"us-west-2": "US West (Oregon)", "us-east-1": "US East (N. Virginia)"}
# Models with complete input+output data in the Price List API (the Nova family).
DEFAULT_PRICE_MODELS = ["Nova Micro", "Nova Lite", "Nova Pro"]


def fetch_bedrock_prices(models=None, region="us-west-2"):
    """Return a tidy DataFrame of live input/output prices ($/1M tokens) per model.

    Queries the AWS Price List API by model name and keeps the standard
    input-tokens / output-tokens line items (ignoring cache/flex/priority variants).
    The Price List API is only served from us-east-1 and needs pricing:GetProducts.

    Args:
        models: list of model display names (defaults to the Nova family).
        region: Bedrock region whose prices to fetch (us-west-2 or us-east-1).
    """
    import boto3

    models = models or DEFAULT_PRICE_MODELS
    location = _REGION_LOCATION[region]
    pricing = boto3.client("pricing", region_name="us-east-1")
    rows = []
    for model in models:
        paginator = pricing.get_paginator("get_products")
        for page in paginator.paginate(
            ServiceCode="AmazonBedrock",
            Filters=[
                {"Type": "TERM_MATCH", "Field": "model", "Value": model},
                {"Type": "TERM_MATCH", "Field": "location", "Value": location},
                {"Type": "TERM_MATCH", "Field": "feature", "Value": "On-demand Inference"},
            ],
        ):
            for item in page["PriceList"]:
                prod = json.loads(item)
                usage = (prod["product"]["attributes"].get("usagetype") or "")
                if usage.endswith("input-tokens"):
                    token_type = "input"
                elif usage.endswith("output-tokens"):
                    token_type = "output"
                else:
                    continue
                for term in prod.get("terms", {}).get("OnDemand", {}).values():
                    for dim in term.get("priceDimensions", {}).values():
                        usd = dim.get("pricePerUnit", {}).get("USD")
                        if usd is None:
                            continue
                        # unit is "1K tokens" -> multiply by 1000 for per-1M
                        rows.append({
                            "Model": model,
                            "Token Type": token_type,
                            "Price ($/1M tokens)": round(float(usd) * 1000, 4),
                        })
    return pd.DataFrame(rows).drop_duplicates().reset_index(drop=True)


def show_bedrock_pricing(models=None, region="us-west-2"):
    """Fetch live Bedrock prices, display a styled table, and return the tidy DataFrame.

    Degrades gracefully: if the Price List API is unavailable (e.g. missing the
    pricing:GetProducts permission), prints guidance and returns an empty DataFrame
    so the notebook can fall back to snapshot prices.
    """
    from IPython.display import display

    try:
        df = fetch_bedrock_prices(models=models, region=region)
    except Exception as e:
        print(f"⚠️  Could not fetch live pricing: {type(e).__name__}")
        print(f"   {str(e)[:160]}")
        print("\n   Grant pricing:GetProducts on this role to enable the live pricing demo.")
        print("   The lab falls back to the documented snapshot prices.")
        return pd.DataFrame()

    if not len(df):
        print("⚠️  No rows returned — those model names may not be published in the Price List API.")
        return df

    print(f"✅ Live on-demand pricing for {region} (AWS Price List API)")
    pivot = (df.pivot(index="Model", columns="Token Type", values="Price ($/1M tokens)")
             .reset_index().rename_axis(None, axis=1))
    # Uppercase headers and add cost unit
    pivot = pivot.rename(columns={
        "Model": "MODEL",
        "input": "INPUT ($/1M TOKENS)",
        "output": "OUTPUT ($/1M TOKENS)",
    })
    fmt = {c: "${:.4f}" for c in pivot.columns if c != "MODEL"}
    styled_table(pivot, caption="Live Bedrock pricing ($ per 1M tokens)", fmt=fmt, center=True)
    return df


def merge_live_pricing(pricing_dict, live_prices_df):
    """Override snapshot pricing with live prices from the Price List API.

    Args:
        pricing_dict: dict of {model_id: {"input": float, "output": float, "name": str}}.
                      Modified in-place.
        live_prices_df: DataFrame returned by show_bedrock_pricing() with columns
                        "Model", "Token Type", "Price ($/1M tokens)".

    Returns:
        True if live prices were applied, False if falling back to snapshot.
    """
    if not len(live_prices_df):
        print("Using snapshot pricing (live pricing unavailable.)")
        return False

    _name_to_id = {v["name"]: k for k, v in pricing_dict.items()}
    for _, row in live_prices_df.iterrows():
        model_name = row["Model"]
        for display_name, model_id in _name_to_id.items():
            if model_name.lower() in display_name.lower() or display_name.lower() in model_name.lower():
                token_type = row["Token Type"]  # "input" or "output"
                pricing_dict[model_id][token_type] = row["Price ($/1M tokens)"]
                break
    print("Using live pricing from AWS Price List API.")
    return True


# ---------------------------------------------------------------------------
# Lab 3 — Threaded workload runner
# ---------------------------------------------------------------------------
def run_threaded_workload(send_fn, threads=4, requests=20, circuit_breaker=None):
    """Run a threaded workload and print results summary.

    Args:
        send_fn: callable(thread_id, requests) -> list[dict] where each dict has a "status" key.
        threads: number of concurrent threads.
        requests: number of requests per thread.
        circuit_breaker: optional CircuitBreaker instance to report state.
    """
    import concurrent.futures

    with concurrent.futures.ThreadPoolExecutor(max_workers=threads) as executor:
        futures = {executor.submit(send_fn, tid, requests): tid for tid in range(threads)}
        all_results = []
        for future in concurrent.futures.as_completed(futures):
            all_results.extend(future.result())

    successes = sum(1 for r in all_results if r.get("status") == "success")
    errors = sum(1 for r in all_results if r.get("status") != "success")
    total = len(all_results)

    print(f"\n{'='*60}")
    print(f"📊 Results")
    print(f"{'='*60}")
    print(f"  ✅ Successful: {successes}/{total}")
    print(f"  ❌ Failed:     {errors}/{total}")
    if circuit_breaker:
        print(f"  Circuit breaker state: {circuit_breaker.state}")

    return all_results

# ---------------------------------------------------------------------------
# Lab 2 — Cache cost utilities
# ---------------------------------------------------------------------------
CACHE_PRICING = {"input": 3.00, "output": 15.00, "cache_write": 3.75, "cache_read": 0.30}


def cache_cost_with(usage, pricing=None):
    """Calculate cost per request WITH caching enabled."""
    p = pricing or CACHE_PRICING
    cw = usage.get("cacheWriteInputTokens", 0)
    cr = usage.get("cacheReadInputTokens", 0)
    return (cw * p["cache_write"] + cr * p["cache_read"]
            + usage["inputTokens"] * p["input"] + usage["outputTokens"] * p["output"]) / 1e6


def cache_cost_without(usage, pricing=None):
    """Calculate cost per request WITHOUT caching (baseline)."""
    p = pricing or CACHE_PRICING
    cw = usage.get("cacheWriteInputTokens", 0)
    cr = usage.get("cacheReadInputTokens", 0)
    total_in = usage["inputTokens"] + cw + cr
    return (total_in * p["input"] + usage["outputTokens"] * p["output"]) / 1e6


def run_cache_experiment(invoke_fn, queries, delay=1.0):
    """Run queries through a cached invoke function and record cost/latency.

    Args:
        invoke_fn: callable(query) -> Converse API response.
        queries: list of query strings to send.
        delay: seconds between requests.

    Returns:
        list of dicts with keys: Query #, Cache Status, Latency (s),
        Cost with cache ($), Cost without cache ($).
    """
    import time
    results = []
    for i, query in enumerate(queries, 1):
        start = time.time()
        resp = invoke_fn(query)
        latency = time.time() - start
        u = resp["usage"]
        cw = u.get("cacheWriteInputTokens", 0)
        cr = u.get("cacheReadInputTokens", 0)
        status = "HIT ✅" if cr > 0 else ("WRITE 📝" if cw > 0 else "MISS ❌")
        results.append({
            "Query #": i,
            "Cache Status": status,
            "Latency (s)": round(latency, 2),
            "Cost with cache ($)": cache_cost_with(u),
            "Cost without cache ($)": cache_cost_without(u),
        })
        time.sleep(delay)
    return results


def summarize_cache_results(detailed_results):
    """Print a table of cache results with a cost savings summary.

    Args:
        detailed_results: list of dicts from run_cache_experiment or run_cache_antipattern,
            with keys "Query #", "Cache Status", "Latency (s)",
            "Cost with cache ($)", "Cost without cache ($)".
    """
    results_df = pd.DataFrame(detailed_results)
    show_df = results_df.assign(**{
        "Cost with cache ($)": results_df["Cost with cache ($)"].map("${:.6f}".format),
        "Cost without cache ($)": results_df["Cost without cache ($)"].map("${:.6f}".format),
    })
    print(tabulate(show_df, headers="keys", tablefmt="grid", showindex=False))

    with_total = results_df["Cost with cache ($)"].sum()
    without_total = results_df["Cost without cache ($)"].sum()
    savings = (1 - with_total / without_total) * 100 if without_total else 0
    hits = (results_df["Cache Status"] == "HIT ✅").sum()
    writes = (results_df["Cache Status"] == "WRITE 📝").sum()
    print(f"\n{'='*60}")
    print(f"💰 Cost Analysis ({len(detailed_results)} requests)")
    print(f"{'='*60}")
    print(f"   Cache writes: {writes}   Cache hits: {hits}")
    print(f"   Total WITHOUT caching: ${without_total:.6f}")
    print(f"   Total WITH caching:    ${with_total:.6f}")
    print(f"   💰 Savings: {savings:.1f}%")


def run_cache_antipattern(bedrock_client, system_instructions, sop_guidelines, tickets,
                          model_id="us.amazon.nova-micro-v1:0", n=20, delay=0.5,
                          pricing=None):
    """Run the cache anti-pattern: ticket text BEFORE the cachePoint (invalidates every call).

    Args:
        bedrock_client: boto3 bedrock-runtime client.
        system_instructions: static system instructions string.
        sop_guidelines: static SOP guidelines string.
        tickets: list of ticket dicts with 'subject' and 'body' keys.
        model_id: model to invoke.
        n: number of queries to run.
        delay: seconds between requests.
        pricing: optional dict with per-1M-token rates ("input", "output",
            "cache_write", "cache_read"). Should match model_id. Defaults to
            CACHE_PRICING (Claude Sonnet rates) when omitted — pass the rates
            for model_id (e.g. Nova Micro) to avoid overstating cost.

    Returns:
        list of dicts ready for plot_cache_performance.
    """
    import time
    results = []
    for i, ticket in enumerate(tickets[:n], 1):
        ticket_text = f"{ticket['subject']}\n{ticket['body']}"

        start = time.time()
        response = bedrock_client.converse(
            modelId=model_id,
            system=[
                {"text": system_instructions},
                {"text": sop_guidelines},
                {"text": f"Current ticket: {ticket_text}"},  # ← BREAKS CACHING
                {"cachePoint": {"type": "default"}}
            ],
            messages=[{"role": "user", "content": [{"text": "Classify and respond to this ticket."}]}],
            inferenceConfig={"maxTokens": 300}
        )
        latency = time.time() - start
        u = response["usage"]
        cw = u.get("cacheWriteInputTokens", 0)
        cr = u.get("cacheReadInputTokens", 0)
        status = "HIT ✅" if cr > 0 else ("WRITE 📝" if cw > 0 else "MISS ❌")

        results.append({
            "Query #": i,
            "Cache Status": status,
            "Latency (s)": round(latency, 2),
            "Cost with cache ($)": cache_cost_with(u, pricing),
            "Cost without cache ($)": cache_cost_without(u, pricing),
        })
        time.sleep(delay)
    return results
