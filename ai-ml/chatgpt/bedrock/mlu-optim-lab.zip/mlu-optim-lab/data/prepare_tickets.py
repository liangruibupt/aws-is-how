"""
Prepare a curated sample of the Tobi-Bueck/customer-support-tickets dataset
for use in the FLUF2 labs.

Source: https://huggingface.co/datasets/Tobi-Bueck/customer-support-tickets

This script downloads the dataset, filters to clean English tickets, and writes
a balanced 100-ticket sample to support_tickets.jsonl. Each ticket includes
ground-truth labels (queue, priority, type) that the labs use to measure
classification accuracy.

Usage:
    python data/prepare_tickets.py
"""
import json
import random
from collections import Counter

from datasets import load_dataset

OUTPUT_PATH = "data/support_tickets.jsonl"
SAMPLE_SIZE = 100
SEED = 42


def main():
    ds = load_dataset("Tobi-Bueck/customer-support-tickets")["train"]

    cleaned = []
    for r in ds:
        if r["language"] != "en":
            continue
        body = (r["body"] or "").replace("\\n", " ").strip()
        subject = (r["subject"] or "").strip()
        if len(body) < 50 or not subject:
            continue
        cleaned.append({
            "subject": subject,
            "body": body,
            "type": r["type"],
            "queue": r["queue"],
            "priority": r["priority"],
            "tags": [r[f"tag_{i}"] for i in range(1, 6) if r[f"tag_{i}"]],
        })

    random.seed(SEED)
    random.shuffle(cleaned)
    sample = cleaned[:SAMPLE_SIZE]

    with open(OUTPUT_PATH, "w") as f:
        for t in sample:
            f.write(json.dumps(t) + "\n")

    print(f"Wrote {len(sample)} tickets to {OUTPUT_PATH}")
    print("Queue distribution:", Counter(t["queue"] for t in sample).most_common())
    print("Priority distribution:", Counter(t["priority"] for t in sample).most_common())


if __name__ == "__main__":
    main()
