import datetime
import hashlib
import hmac
import random
import time
import pycurl
import sys
from io import BytesIO

# ************* REQUEST VALUES *************
service = 'kinesis'
host = 'kinesis.cn-north-1.amazonaws.com.cn'
region = 'cn-north-1'
endpoint = 'https://kinesis.cn-north-1.amazonaws.com.cn'
access_key = ''
secret_key = ''

method = 'POST'
content_type = 'application/x-amz-json-1.1'
amz_target = 'Kinesis_20131202.PutRecords'

# Read the test json file
f1 = open('./HB_Notification_Sample', 'r', newline=None)
blob = f1.read(-1)
f1.close()


# Key derivation functions. See:
# http://docs.aws.amazon.com/general/latest/gr/signature-v4-examples.html#signature-v4-examples-python
def sign(key, msg):
    return hmac.new(key, msg.encode("utf-8"), hashlib.sha256).digest()


def getSignatureKey(key, date_stamp, regionName, serviceName):
    kDate = sign(('AWS4' + key).encode('utf-8'), date_stamp)
    kRegion = sign(kDate, regionName)
    kService = sign(kRegion, serviceName)
    kSigning = sign(kService, 'aws4_request')
    return kSigning

rlist = random.sample('abcdefghijklmnopqrstuvwxyz',6)
fname = "./result/" + "".join(rlist) + ".csv"
f2=open(fname,'w+')
f2.write("Time,Latency(ms),Count\n")
f2.flush()

# call pycurl
conn = pycurl.Curl()
conn.setopt(pycurl.POST, 1)
conn.setopt(pycurl.URL, endpoint)
# resue connection
conn.setopt(pycurl.MAXAGE_CONN,300)

for i in range(1, 20):
    #pkey = sys.argv[1]
    #pkey = "A01"
    pkey = "".join(random.sample("abcdefghijklmnoqprstuvwxyz01234567890",8))
    request_parameters = '{'
    request_parameters += '"Records": ['
    request_parameters += '{'
    request_parameters += '"Data":' + '"' + blob + '",'
    request_parameters += '"PartitionKey":' + '"' + pkey + '"'
    request_parameters += '},'
    request_parameters += '{'
    request_parameters += '"Data":' + '"' + blob + '",'
    request_parameters += '"PartitionKey":' + '"' + pkey + '"'
    request_parameters += '},'
    request_parameters += '{'
    request_parameters += '"Data":' + '"' + blob + '",'
    request_parameters += '"PartitionKey":' + '"' + pkey + '"'
    request_parameters += '},'
    request_parameters += '{'
    request_parameters += '"Data":' + '"' + blob + '",'
    request_parameters += '"PartitionKey":' + '"' + pkey + '"'
    request_parameters += '},'
    request_parameters += '{'
    request_parameters += '"Data":' + '"' + blob + '",'
    request_parameters += '"PartitionKey":' + '"' + pkey + '"'
    request_parameters += '}'
    request_parameters += '],'
    request_parameters += '"StreamName": "cummins_stream"'
    request_parameters += '}'
    #print(request_parameters)

    payload_hash = hashlib.sha256(request_parameters.encode('utf-8')).hexdigest()

    # Create a date for headers and the credential string
    t = datetime.datetime.utcnow()
    amz_date = t.strftime('%Y%m%dT%H%M%SZ')
    date_stamp = t.strftime('%Y%m%d')  # Date w/o time, used in credential scope

    # ************* TASK 1: CREATE A CANONICAL REQUEST *************
    canonical_uri = '/'
    canonical_querystring = ''
    canonical_headers = 'content-type:' + content_type + '\n' + 'host:' + host + '\n' + 'x-amz-date:' + amz_date + '\n' + 'x-amz-target:' + amz_target + '\n'
    signed_headers = 'content-type;host;x-amz-date;x-amz-target'
    canonical_request = method + '\n' + canonical_uri + '\n' + canonical_querystring + '\n' + canonical_headers + '\n' + signed_headers + '\n' + payload_hash

    # ************* TASK 2: CREATE THE STRING TO SIGN*************
    algorithm = 'AWS4-HMAC-SHA256'
    credential_scope = date_stamp + '/' + region + '/' + service + '/' + 'aws4_request'
    string_to_sign = algorithm + '\n' + amz_date + '\n' + credential_scope + '\n' + hashlib.sha256(
        canonical_request.encode('utf-8')).hexdigest()

    # ************* TASK 3: CALCULATE THE SIGNATURE *************
    # Create the signing key using the function defined above.
    signing_key = getSignatureKey(secret_key, date_stamp, region, service)
    signature = hmac.new(signing_key, (string_to_sign).encode('utf-8'), hashlib.sha256).hexdigest()

    # ************* TASK 4: ADD SIGNING INFORMATION TO THE REQUEST *************
    # Put the signature information in a header named Authorization.
    authorization_header = algorithm + ' ' + 'Credential=' + access_key + '/' + credential_scope + ', ' + 'SignedHeaders=' + signed_headers + ', ' + 'Signature=' + signature

    headers = ['Content-Type:' + content_type,
               'X-Amz-Date:' + amz_date,
               'X-Amz-Target:' + amz_target,
               'Authorization:' + authorization_header
               ]
    
    # ************* SEND THE REQUEST *************
    buffer = BytesIO()
    conn.setopt(pycurl.WRITEDATA, buffer)
    conn.setopt(pycurl.HTTPHEADER, headers)
    conn.setopt(pycurl.POSTFIELDS, request_parameters)
    try:
        tic = time.perf_counter()
        conn.perform()
        toc = time.perf_counter()
        status_code = conn.getinfo(conn.RESPONSE_CODE)
        #print(status_code)
    except:
        f2.write(datetime.datetime.now().strftime('%Y%m%d %H:%M:%S') + "," + "-1" + "," + str(i) + "\n")
        #print(datetime.datetime.now().strftime('%Y%m%d %H:%M:%S') + "," + "-1" + "," + str(i) + "\n")
    if status_code == 200:
        f2.write(datetime.datetime.now().strftime('%Y%m%d %H:%M:%S') + "," + str(round((toc - tic)*1000)) + "," + str(i) + "\n")
        print(datetime.datetime.now().strftime('%Y%m%d %H:%M:%S') + "," + str((toc - tic)*1000) + "," + str(i))

    buffer.close()    
    f2.flush()

f2.close()
